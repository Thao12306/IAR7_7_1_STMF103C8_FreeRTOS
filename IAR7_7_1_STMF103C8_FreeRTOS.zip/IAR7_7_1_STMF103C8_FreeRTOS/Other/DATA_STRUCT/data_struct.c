/*  
*data_struct.c V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : ���ݽṹ����
*
*
*/

/*######################################ͷ�ļ�##################################*/

#include "../Includes/header_config.h"

#if LOOP_QUEUE_NUM>0

/*######################################ȫ�ֱ���################################*/

LOOP_QUEUE_LIST  loop_queue_list[LOOP_QUEUE_NUM];

/*######################################����ʵ��################################*/

/*******************************************************************************
* FunctionName   : void Loop_Queue_Init(LOOP_QUEUE_LIST *queue)
* Description    : ���г�ʼ��
* EntryParameter : ����
* ReturnValue    : ��
********************************************************************************/

void Loop_Queue_Init(LOOP_QUEUE_LIST *queue)
{
  queue->head_pointer = 0;
  queue->tail_pointer = 0;
  
  memset(queue->array,0,LOOP_QUEUE_SIZE_MAX);
}

/*******************************************************************************
* FunctionName   : U8 Loop_Queue_Push(LOOP_QUEUE_LIST *queue,U8 *pdat,U16 len)
* Description    : ���
* EntryParameter : ����
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Loop_Queue_Push(LOOP_QUEUE_LIST *queue,U8 *pdat,U16 len)
{
  U16 next_position = 0;
  U16 index_pdat = 0;//ָ������
  U16 i = 0;
   
  if(!pdat)
  {
    return LOOP_QUEUE_ERR_NULL;
  }
  
  if(!len)
  {
    return LOOP_QUEUE_ERR_INVA;
  }
  
  for(i=0;i<len;i++)
  {
    next_position = ((queue->head_pointer + 1)%LOOP_QUEUE_SIZE_MAX);
    
    if(next_position!=queue->tail_pointer)//���пռ�
    {
      queue->array[next_position - 1] = pdat[index_pdat++];
      queue->head_pointer = next_position;//ͷָ����ǰ�ƶ�
    }
    else//��������
    {
      queue->array[queue->head_pointer] = pdat[index_pdat];
      return LOOP_QUEUE_ERR_DATA;
    }
  }
  
  return LOOP_QUEUE_ERR_NONE; 
}

/*******************************************************************************
* FunctionName   : U8 Loop_Queue_Pop(LOOP_QUEUE_LIST *queue,U8 *pdat,U16 len)
* Description    : ����
* EntryParameter : ����
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Loop_Queue_Pop(LOOP_QUEUE_LIST *queue,U8 *pdat,U16 len)
{
  U16 i = 0;
   
  if(!pdat)
  {
    return LOOP_QUEUE_ERR_NULL;
  }
  
  if(!len)
  {
    return LOOP_QUEUE_ERR_INVA;
  }
  
  for(i=0;i<len;i++)
  {
    
    if(queue->tail_pointer!=queue->head_pointer)//���пռ�
    {
      pdat[i] = queue->array[queue->tail_pointer];
      queue->tail_pointer = ((queue->tail_pointer + 1)%LOOP_QUEUE_SIZE_MAX);//��ȡ��β��ַ
    }
    else//�ն���
    {
      pdat[i] = queue->array[queue->tail_pointer];
      return LOOP_QUEUE_ERR_DATA;
    } 
  }
  
  return LOOP_QUEUE_ERR_NONE; 
}

/*******************************************************************************
* FunctionName   : U8 Mid_Get_Queue_len(USART_QUEUE *queue)
* Description    : ��ȡ���г���
* EntryParameter : ����
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U16 Loop_Get_Queue_len(LOOP_QUEUE_LIST *queue)
{
  return ((queue->head_pointer + LOOP_QUEUE_SIZE_MAX - queue->tail_pointer)%LOOP_QUEUE_SIZE_MAX); 
}

#endif


