/*  
*key.h V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : �����ڵײ����
*
*
*/

#ifndef __KEY_H__
#define __KEY_H__

#include "../Includes/type.h"
#include "../Includes/set_parameters.h"

/*######################################���Ŷ���################################*/

#define KEY_PIN_0                       GPIO_Pin_0
#define KEY_PIN_1                       GPIO_Pin_1
#define KEY_PIN_2                       GPIO_Pin_4
#define KEY_PIN_3                       GPIO_Pin_5
#define KEY_PIN_4                       GPIO_Pin_6
#define KEY_PIN_5                       GPIO_Pin_7

#define KEY_PORT_PIN                    GPIOA

#define KEY_CLK_PIN                     RCC_APB2Periph_GPIOA     

/*��������ʱ״̬*/

#define KEY_0 0X01
#define KEY_1 0X02
#define KEY_2 0X10
#define KEY_3 0X20
#define KEY_4 0X40
#define KEY_5 0X80

/*######################################ö�ٶ���################################*/



/*######################################�����嶨��##############################*/



/*######################################�ṹ�嶨��##############################*/



/*######################################ȫ�ֱ���################################*/



/*######################################�ⲿ����################################*/


/*######################################��ʼ����������##########################*/

extern void Div_Key_Init(void);

/*######################################�ڲ���������############################*/

void Div_Key_Read(void);

/*######################################����ú�������##########################*/

extern U8 key_scan(void);
#endif

/*######################################## END OF FILE #########################*/

