/*  
*crc.c V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : CRCУ�����
*
*
*/

/*######################################ͷ�ļ�##################################*/

#include "../Includes/header_config.h"

/*######################################ȫ�ֱ���################################*/


/*######################################����ʵ��################################*/

/*******************************************************************************
* FunctionName   : U16 CAL_CRCITT(U8 *paddr,U16 cnt,U16 crc)
* Description    : CRC����
* EntryParameter : ����
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U16 CAL_CRCITT(U8 *paddr,U16 cnt,U16 crc)
{
  U8 i;
  
  if(!paddr)
  {}
  
  for(;cnt>0;cnt--)
  {
    crc = crc^(((U16)(*paddr++))<<8);
    for(i=0;i<8;i++)
    {
      if(crc&0x8000)crc = (crc<<1)^0X1021;
      else crc<<=1;
    }
    crc &= 0xffff;
  }
  return (crc);
}

/*******************************************************************************
* FunctionName   : U16 CAL_XOR(U8 *paddr,U16 cnt)
* Description    : ������
* EntryParameter : ����
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 CAL_XOR(U8 *paddr,U16 cnt)
{
  U16 i = 0;
  U8 sum = 0;
  
  for(i=0;i<cnt;i++)
  {
    sum ^= *paddr++;
  }
  
  return (sum);
}














