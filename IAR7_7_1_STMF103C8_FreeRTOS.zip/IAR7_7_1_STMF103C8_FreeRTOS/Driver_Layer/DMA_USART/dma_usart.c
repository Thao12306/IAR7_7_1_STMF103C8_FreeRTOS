/*  
*dma_usart.c V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : usart_DMA�ײ����
*
*
*/

/*######################################ͷ�ļ�##################################*/

#include "../Includes/header_config.h"

/*######################################����˵��################################*/
/*
          num     Name    Pin        Pin_STATE   
          1       W25QXX  /WP(3)     ͨ�����������VCC        
          2       W25QXX  /HOLD(7)   ͨ�����������VCC  
          
         ����
         num        Pin_CS  Pin_SCLK  Pin_MISO  Pin_MOSI
         оƬ���   1       6         2         5
*
* ��Чʹ�÷�Χ
*
* STM32F103C8           num 1/2      
* STM32F103RC           num 1/2
*/

/*######################################ȫ�ֱ���################################*/

#if USART_DMA_EN == 1



/*######################################����ʵ��################################*/

void Div_Dma_Usart_Create(void)
{
  Div_Dma_Usart_Init();
}

/*******************************************************************************
* FunctionName   : void Div_dma_usart_Init(USART_DMA_DATA_LIST *pusart_dma)
* Description    : ��ʼ��
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_Dma_Usart_Init(USART_DMA_DATA_LIST *pusart_dma)
{
  DMA_InitTypeDef DMA_InitStructure;

  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

  DMA_Cmd(DMA1_Channel4, DISABLE);              //�ر�DMA  
  DMA_DeInit(DMA1_Channel4);                    //�ָ���ʼֵ   

  DMA_InitStructure.DMA_PeripheralBaseAddr =(uint32_t)(&(USART1->DR));	
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)pusart_dma->usart_dma_txbuff;

  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;	
  DMA_InitStructure.DMA_BufferSize = pusart_dma->usart_dma_buffsize;   

  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable; 
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;	

  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;	

  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;	 

  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium; 
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;

  DMA_Init(DMA1_Channel4, &DMA_InitStructure);
  DMA_ClearFlag(DMA1_FLAG_GL4);                 //������б�� 
  DMA_Cmd(DMA1_Channel4, DISABLE);              //�ر�DMA 			
  DMA_ITConfig(DMA1_Channel4,DMA_IT_TC,ENABLE); //DMA�����ж� 

  /*RX************************/

  DMA_Cmd(DMA1_Channel5, DISABLE);              //�ر�DMA  
  DMA_DeInit(DMA1_Channel5);                    //�ָ���ʼֵ   

  DMA_InitStructure.DMA_PeripheralBaseAddr =(uint32_t)(&(USART1->DR));	
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)pusart_dma->usart_dma_rxbuff;

  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;	
  DMA_InitStructure.DMA_BufferSize = pusart_dma->usart_dma_buffsize;   

  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable; 
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;	

  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;	

  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;	 

  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium; 
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;

  DMA_Init(DMA1_Channel5, &DMA_InitStructure);
  DMA_ClearFlag(DMA1_FLAG_GL5);                 //������б��  
  DMA_Cmd(DMA1_Channel5, ENABLE);               //ʹ��DMA 
  
}

/*******************************************************************************
* FunctionName   : void Div_Dma_StartWork(uint16_t psize)
* Description    : USART-DMA����
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/  
  
void Div_Dma_StartWork(uint16_t psize)
{
  DMA1_Channel4->CNDTR = (uint16_t)psize;
  DMA_Cmd(DMA1_Channel4, ENABLE);
}

/*******************************************************************************
* FunctionName   : void Div_Dma_Usart_SetRecNvic(void)
* Description    : USART-DMA�жϽ��ճ�ʼ��
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_Dma_Usart_SetRecNvic(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;

  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);

  NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel4_IRQn;  
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;    
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
}

/*******************************************************************************
* FunctionName   : void DMA1_Channel4_IRQHandler(void)
* Description    : USART-DMA�жϷ����жϺ���
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void DMA1_Channel4_IRQHandler(void)
{
  if(DMA_GetITStatus(DMA1_IT_TC4))              //�������
  {
    DMA_ClearITPendingBit(DMA1_IT_TC4);
    DMA_Cmd(DMA1_Channel4, DISABLE);            //�ر�DMA
  }
}

/*�жϷ������� usart.c*/

#endif







