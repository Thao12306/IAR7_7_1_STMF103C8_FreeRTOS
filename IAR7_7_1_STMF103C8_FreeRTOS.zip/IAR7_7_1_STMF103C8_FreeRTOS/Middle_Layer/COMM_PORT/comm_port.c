/*  
*comm_prot.c V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : �����м�����(ͨ��Э��)
*
*
*/

/*######################################ͷ�ļ�##################################*/

#include "../Includes/header_config.h"

/*######################################ȫ�ֱ���################################*/

u8 COMM_REC_TABLE[COMM_SIZE_MAX];            //���ڽ��ջ���
u8 CMM_FRAME_TABLE[COMM_SIZE_MAX];           //����֡���ջ���

/*######################################����ʵ��#################################*/

/*******************************************************************************
* FunctionName   : U8 Mid_Comm_SendAck_Dat(U16 cmd,U16 len,U8 ack,U8 *pdat)
* Description    : ��������(Э��)
* EntryParameter : ����
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

/*-----------------------------------------------------------
*     ֡ͷ     ����     ����      ����      У��       ֡β
*------------------------------------------------------------
*    0XAA     cmd      len+1     N         crc        0XAB
*------------------------------------------------------------
*  1 byte   2 bytes    2 bytes   N bytes   1 bytes    1 byte
*/

void Mid_Comm_SendAck_Dat(U16 cmd,U16 len,U8 ack,U8 *pdat)
{
  U16 index = 0;
  U8 crc_sum = 0;
  
  U8 temp_table[COMM_SIZE_MAX] = {0};
  U8 temp_table2[COMM_SIZE_MAX] = {0};
  
  temp_table[index++] = COMM_HEAD_CODE;
  
  MATH_U16_TO_ARRAY(&temp_table[index],cmd);
  index += 2;
  
  MATH_U16_TO_ARRAY(&temp_table[index],(len+1));
  index += 2;
  
  temp_table[index++] = ack;
  
  memcpy(&temp_table[index],pdat,len);
  index += len;
  
  crc_sum = CAL_XOR(&temp_table[1], index-1);
  temp_table[index++] = crc_sum;
  
  temp_table[index++] = COMM_TAIL_CODE;
  
  index =  Data_Escape(temp_table2,temp_table,index);
  
  Mid_Link_Div_UsartSend(index,temp_table2);
  
}

/*******************************************************************************
* FunctionName   : U8 Mid_Comm_Send_Dat(U8 *pdat)
* Description    : ��������(Э��)
* EntryParameter : ����
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

/*-----------------------------------------------------------
*     ֡ͷ     ����     ����      ����      У��       ֡β
*------------------------------------------------------------
*    0XAA     cmd      len       N         crc        0XAB
*------------------------------------------------------------
*  1 byte   2 bytes    2 bytes   N bytes   1 bytes    1 byte
*/

void Mid_Comm_Send_Dat(U16 cmd,U16 len,U8 *pdat)
{
  U16 index = 0;
  U8 crc_sum = 0;
  
  U8 temp_table[COMM_SIZE_MAX] = {0};
  U8 temp_table2[COMM_SIZE_MAX] = {0};
  
  temp_table[index++] = COMM_HEAD_CODE;//֡ͷ
  
  MATH_U16_TO_ARRAY(&temp_table[index],cmd);//����
  index += 2;
  
  MATH_U16_TO_ARRAY(&temp_table[index],len);//����
  index += 2;
  
  memcpy(&temp_table[index],pdat,len);//����
  index += len;
  
  crc_sum = CAL_XOR(&temp_table[1], index-1);//��֡ͷ֡β֮��
  temp_table[index++] = crc_sum;
  
  temp_table[index++] = COMM_TAIL_CODE;//֡β
  
  index =  Data_Escape(temp_table2,temp_table,index);

  Mid_Link_Div_UsartSend(index,temp_table2);
  
}

/************************************************************************************-----�ռ����ú���-----**/
/*******************************************************************************
* FunctionName   : U8 Mid_Comm_FrameFormat_Proc(void)
* Description    : ֡��ʽ����
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

/*-----------------------------------------------------------
*     ֡ͷ     ����     ����      ����      У��       ֡β
*------------------------------------------------------------
*    0XAA     cmd      len       N         crc        0XAB
*------------------------------------------------------------
*  1 byte   2 bytes    2 bytes   N bytes   1 bytes    1 byte
*/

void Mid_Comm_FrameFormat_Proc(void)
{
  U8 ack_err = 0;
    
  U16 temp_len = 0;
  U16 temp_cmd = 0;
  
  U8 temp_table[COMM_SIZE_MAX] = {0};
  
  if(Link_Frame_Link(COMM_TASK_NUM,&comm_frame_list)==COMM_ERR_NONE)
  {
    temp_len = Data_UnEscape(temp_table,comm_frame_list.frame_rbuff,comm_frame_list.frame_len);
    
    Div_Usart_Send_Byte(0,(uint8_t)temp_len);
    //printf("%d ",temp_len);
    
    temp_cmd = MATH_ARRAY_TO_U16(&temp_table[COMM_CMD_POS]);//��������λ��
    
    if(CAL_XOR(&temp_table[1],temp_len-2)!=0)//У����� ���������ֵΪ0
    {
      ack_err = ACK_CHECK_ERR;
    }
    else if(MATH_ARRAY_TO_U16(&temp_table[3])!=temp_len-7)//���ݳ��ȳ���
    {
      ack_err = ACK_LEN_ERR;
    }
    else
    {
      temp_len = MATH_ARRAY_TO_U16(&temp_table[COMM_LEN_POS]);
      ack_err = Mid_Comm_Cmd_Deal(temp_cmd,temp_len,&temp_table[COMM_DATA_POS]);//�����������  
    }
    if(ack_err>0)//���ݴ���
    {
      Mid_Comm_SendAck_Dat(temp_cmd|CMD_ACK_DAT,0,ack_err,NULL);
    }
    Link_Clear_Frame(&comm_frame_list);//���֡������
  }
  
}

/*******************************************************************************
* FunctionName   : U8 Mid_Comm_Cmd_Deal(U16 cmd,U16 len,U8 *pdat)
* Description    : �����
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

U8 Mid_Comm_Cmd_Deal(U16 cmd,U16 len,U8 *pdat)
{
  U8 rec_value = 0;
  
  switch(cmd)
  {
    case CMD_SET_LED:rec_value = func_0(pdat,len);break;
    
    /*�����������ܴ��������ĵ��ú���*/
    
    default:rec_value = 1;break;
  }

  return rec_value;
}

/*******************************************************************************
* FunctionName   : U8 func_0(U8 *pdat,U16 len)
* Description    : �����
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

U8 func_0(U8 *pdat,U16 len)
{
  Div_Usart_Send_String(T_USART1,"12345678");
  return 0;
}

/*�����������ܴ�������*/


/*******************************************************************************
* FunctionName   : void Mid_Comm_Init(void)
* Description    : �����
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

void Mid_Comm_Init(void)
{

//  U8 temp_table[3] = {0x01,0xAA,0X00};
//  U8 temp_table2[3] = {0x01,0xAB,0X00};
  
  Link_FrameData_Create(COMM_TASK_NUM,COMM_REC_TABLE,COMM_SIZE_MAX);
  Link_FrameFormat_Create("\x01\x7E\x00","\x01\x7F\x00",7,CMM_FRAME_TABLE,COMM_SIZE_MAX,&comm_frame_list);
  
}

































