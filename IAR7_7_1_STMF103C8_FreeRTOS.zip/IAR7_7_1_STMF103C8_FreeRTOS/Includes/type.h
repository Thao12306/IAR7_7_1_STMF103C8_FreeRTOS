/*  
*type.h V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : 
*DebugTools     : 
*Description    : ϵͳ�������ͱ������� 
*
*
*/

#ifndef __TYPE_H__
#define __TYPE_H__

/*######################################�������Ͷ���############################*/

typedef char                          I8;					
typedef short                         I16; 					
typedef long                          I32; 					

typedef char const                    IC8;					
typedef short const                   IC16; 					
typedef int const                     IC32;  					

typedef volatile char                 VI8;					
typedef volatile short                VI16; 					
typedef volatile int                  VI32; 					

typedef volatile char const           VIC8;					
typedef volatile short const          VIC16; 					
typedef volatile int const            VIC32;					

typedef signed   char                 S8;					
typedef signed   short                S16; 					
typedef signed   long                 S32; 					
 
typedef signed   char const           SC8;					
typedef signed   short const          SC16; 					
typedef signed   int const            SC32;  					

typedef volatile signed char          VS8;					
typedef volatile signed short         VS16; 					
typedef volatile signed int           VS32; 					

typedef volatile signed char const    VSC8;					
typedef volatile signed short const   VSC16; 					
typedef volatile signed int const     VSC32;					

typedef unsigned char                 U8; 					
typedef unsigned int                  U16; 					
typedef unsigned long                 U32; 				        

typedef unsigned char const           UC8;				        
typedef unsigned short const          UC16; 					
typedef unsigned int const            UC32;  					

typedef volatile unsigned char        VU8;					
typedef volatile unsigned short       VU16; 					
typedef volatile unsigned int         VU32; 					

typedef volatile unsigned char  const VUC8;				        
typedef volatile unsigned short const VUC16; 					
typedef volatile unsigned int   const VUC32;					

typedef float                         FP32;                                          
typedef double                        FP64;

#endif

/*######################################## END OF FILE #########################*/

