/*  
*spi.c V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : SPI�ײ����
*
*
*/

/*######################################ͷ�ļ�##################################*/

#include "../Includes/header_config.h"

/*######################################����˵��################################*/
/*
          num     Name    Pin_CS    Pin_SCLK   Pin_MISO    Pin_MOSI 
          1       SPI1    PA4       PA5        PA6         PA7
          2       SPI2    PB12      PB13       PB14        PB15
          3       SPI3    PA15      PB3        PB4         PB5
*
* ��Чʹ�÷�Χ
*
* STM32F103C8           num 1/2      
* STM32F103RC           num 1/2/3 
*/

/*######################################ȫ�ֱ���################################*/

SPI_TypeDef* Spi_List[] = {SPI1,SPI2,SPI3};

/*######################################����ʵ��################################*/

#if SOFTWARE_SPI_EN == 0

/*******************************************************************************
* FunctionName   : U8 Div_Spi_Select_Clock(U8 ch)
* Description    : ѡ��SPIʱ��
* EntryParameter : SPI���
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Div_Spi_Select_Clock(U8 ch)
{
  switch(ch)
  {
    case T_SPI1:
      {
        RCC_APB2PeriphClockCmd(SPI_CLK_CS1,ENABLE);
        RCC_APB2PeriphClockCmd(SPI_CLK_SCLK1|SPI_CLK_MISO1|SPI_CLK_MOSI1,ENABLE);
        
        RCC_APB2PeriphClockCmd(SPI_CLK_1,ENABLE);

        break;
      }
    case T_SPI2:
      {
        RCC_APB2PeriphClockCmd(SPI_CLK_CS2,ENABLE);
        RCC_APB2PeriphClockCmd(SPI_CLK_SCLK2|SPI_CLK_MISO2|SPI_CLK_MOSI2,ENABLE);
        
        RCC_APB1PeriphClockCmd(SPI_CLK_2,ENABLE);

        break;
      }
    case T_SPI3:/*PB3 ����*/
      {
        RCC_APB2PeriphClockCmd(SPI_CLK_CS3,ENABLE);
        RCC_APB2PeriphClockCmd(SPI_CLK_SCLK3|SPI_CLK_MISO3|SPI_CLK_MOSI3,ENABLE);
        
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
        
        RCC_APB1PeriphClockCmd(SPI_CLK_3,ENABLE);
        
        GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE); 
        GPIO_PinRemapConfig(GPIO_Remap_SPI3,ENABLE);
        break;
      }
    default:break;
  }
  return 0;
}

/*******************************************************************************
* FunctionName   : U8 Div_Spi_Gpio_Set(U8 num)
* Description    : ����SPIӲ������
* EntryParameter : SPI���
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Div_Spi_Gpio_Set(U8 num)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  
  switch(num)
  {
    case T_SPI1:
      {
        GPIO_InitStructure.GPIO_Pin = SPI_PIN_CS1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(SPI_PORT_CS1, &GPIO_InitStructure);
        
        GPIO_SetBits(SPI_PORT_CS1,SPI_PIN_CS1);
        
        GPIO_InitStructure.GPIO_Pin = SPI_PIN_SCLK1;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(SPI_PORT_SCLK1, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin = SPI_PIN_MISO1;
        GPIO_Init(SPI_PORT_MISO1, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin = SPI_PIN_MOSI1;
        GPIO_Init(SPI_PORT_MOSI1, &GPIO_InitStructure);
        
        break;
      }
  
    case T_SPI2:
      {
	GPIO_InitStructure.GPIO_Pin = SPI_PIN_CS2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(SPI_PORT_CS2, &GPIO_InitStructure);
        
        GPIO_SetBits(SPI_PORT_CS2,SPI_PIN_CS2);
        
        GPIO_InitStructure.GPIO_Pin = SPI_PIN_SCLK2;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(SPI_PORT_SCLK2, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin = SPI_PIN_MISO2;
        GPIO_Init(SPI_PORT_MISO2, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin = SPI_PIN_MOSI2;
        GPIO_Init(SPI_PORT_MOSI2, &GPIO_InitStructure);
        
        break;
      }
      
    case T_SPI3:
      {
        GPIO_InitStructure.GPIO_Pin = SPI_PIN_CS3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(SPI_PORT_CS3, &GPIO_InitStructure);
        
        GPIO_SetBits(SPI_PORT_CS3,SPI_PIN_CS3);
        
        GPIO_InitStructure.GPIO_Pin = SPI_PIN_SCLK3;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(SPI_PORT_SCLK3, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin = SPI_PIN_MISO3;
        GPIO_Init(SPI_PORT_MISO3, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin = SPI_PIN_MOSI3;
        GPIO_Init(SPI_PORT_MOSI3, &GPIO_InitStructure);
       
        break;
      }

    default:break;
    
  }
  
  return 0;
}

/*******************************************************************************
* FunctionName   : U8 Div_Spi_Set(U8 num,U32 BaudRate)
* Description    : ����SPI����Ƶֵ
* EntryParameter : SPI�ţ���Ƶֵ
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Div_Spi_Set(U8 num,U8 SPI_BaudRatePrescaler)
{
  U8 clear = 0;
  
  SPI_InitTypeDef  SPI_InitStructure;
  
  RCC_APB1PeriphClockCmd(SPI_CLK_2,ENABLE);
  
  SPI_Cmd(Spi_List[num], DISABLE);

  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler;
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
  SPI_InitStructure.SPI_CRCPolynomial = 7;
  SPI_Init(Spi_List[num],&SPI_InitStructure);

  clear = Spi_List[num] ->DR;//clear OverRun error
  clear = Spi_List[num] ->SR;//clear UnderRun error
	
  SPI_Cmd(Spi_List[num],ENABLE);

  return 0;
}

/*******************************************************************************
* FunctionName   : U8 Div_Spi_Init(U8 num,U8 SPI_BaudRatePrescaler)
* Description    : ����SPI
* EntryParameter : SPI�š���Ƶֵ
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Div_Spi_Init(U8 num,U8 SPI_BaudRatePrescaler,U32 buff_size)
{
  
  Div_Spi_Select_Clock(num);
  Div_Spi_Gpio_Set(num);
  Div_Spi_Set(num,SPI_BaudRatePrescaler);
  
#if (SPI_DMA_EN == 1) && (SPI_DMA_NUM_MAX>0)
 
  Div_dma_flash_Init(buff_size);
  
#endif
 
  return 0;
}

/*******************************************************************************
* FunctionName   : U8 Div_Spi_ReadWrite_Byte(U8 num,U8 dat)
* Description    : ��дһ���ֽ�����
* EntryParameter : SPI�š�����
* ReturnValue    : ���ص�����
********************************************************************************/

U8 Div_Spi_ReadWrite_Byte(U8 num,U8 dat)
{
  U8 Redata = 0;

  while (SPI_I2S_GetFlagStatus(Spi_List[num], SPI_I2S_FLAG_TXE) == RESET) 
  {
  }		

  SPI_I2S_SendData(Spi_List[num], dat); 

  while (SPI_I2S_GetFlagStatus(Spi_List[num], SPI_I2S_FLAG_RXNE) == RESET)
  {
  }	
  
  Redata = SPI_I2S_ReceiveData(Spi_List[num]);	
  
  return Redata;
  
}

/*******************************************************************************
* FunctionName   : U8 Div_Spi_Write_Byte(U8 num,U8 dat)
* Description    : дһ���ֽ�����
* EntryParameter : SPI�š�����
* ReturnValue    : ��
********************************************************************************/

U8 Div_Spi_Write_Byte(U8 num,U8 dat)
{
  while (SPI_I2S_GetFlagStatus(Spi_List[num], SPI_I2S_FLAG_TXE) == RESET) 
  {
  }		

  SPI_I2S_SendData(Spi_List[num], dat); 

  while (SPI_I2S_GetFlagStatus(Spi_List[num], SPI_I2S_FLAG_RXNE) == RESET)
  {
  }	
  
  SPI_I2S_ReceiveData(Spi_List[num]);	
  
  return 0;
  
}

/*******************************************************************************
* FunctionName   : U8 Div_Spi_Read_Byte(U8 num)
* Description    : ��һ���ֽ�����
* EntryParameter : SPI��
* ReturnValue    : ���ص�����
********************************************************************************/

U8 Div_Spi_Read_Byte(U8 num)
{
  U8 Redata = 0;
  
  while (SPI_I2S_GetFlagStatus(Spi_List[num], SPI_I2S_FLAG_TXE) == RESET) 
  {
  }		

  SPI_I2S_SendData(Spi_List[num], 0XFF); 

  while (SPI_I2S_GetFlagStatus(Spi_List[num], SPI_I2S_FLAG_RXNE) == RESET)
  {
  }	
  
  Redata = SPI_I2S_ReceiveData(Spi_List[num]);	
  
  return Redata;
  
}

/*******************************************************************************
* FunctionName   : U8 Div_Spi_Speed_Set(U8 num,U8 SPI_BaudRatePrescaler)
* Description    : ����SPI�ٶ�
* EntryParameter : SPI�š���Ƶֵ
* ReturnValue    : ��
********************************************************************************/

U8 Div_Spi_Speed_Set(U8 num,U8 SPI_BaudRatePrescaler)
{
  assert_param(IS_SPI_ALL_PERIPH(Spi_List[num]));
  assert_param(IS_SPI_BAUDRATE_PRESCALER(SPI_BaudRatePrescaler));
  Spi_List[num]->CR1&=0XFFC7;
  Spi_List[num]->CR1|=SPI_BaudRatePrescaler;	
  SPI_Cmd(Spi_List[num],ENABLE); 
  
  return 0;
  
}

#else

/*******************************************************************************
* FunctionName   : void Div_SpiSoftware_Init(void)
* Description    : ����SPI
* EntryParameter : SPI�š���Ƶֵ
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

/*Ĭ��ģ��SPI�ӿ�ΪӲ��SPI2�ӿ�*/

void Div_SpiSoftware_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  RCC_APB2PeriphClockCmd(SOFTWARE_CLK_CS, ENABLE);
  RCC_APB2PeriphClockCmd(SOFTWARE_CLK_SCLK, ENABLE);
  RCC_APB2PeriphClockCmd(SOFTWARE_CLK_MISO, ENABLE);
  RCC_APB2PeriphClockCmd(SOFTWARE_CLK_MOSI, ENABLE);

  //NSS SoftWare
  GPIO_InitStructure.GPIO_Pin = SOFTWARE_PIN_CS;  
  GPIO_InitStructure.GPIO_Mode =GPIO_Mode_Out_PP;  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(SOFTWARE_PORT_CS,&GPIO_InitStructure);

  //SCK SoftWare
  GPIO_InitStructure.GPIO_Pin = SOFTWARE_PIN_SCLK;  
  GPIO_InitStructure.GPIO_Mode =GPIO_Mode_Out_PP;  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(SOFTWARE_PORT_SCLK,&GPIO_InitStructure);

  //MISO SoftWare
  GPIO_InitStructure.GPIO_Pin = SOFTWARE_PIN_MISO;  
  GPIO_InitStructure.GPIO_Mode =GPIO_Mode_IPU;  
  GPIO_Init(SOFTWARE_PORT_MISO,&GPIO_InitStructure);

  //MOSI SoftWare
  GPIO_InitStructure.GPIO_Pin = SOFTWARE_PIN_MOSI;  
  GPIO_InitStructure.GPIO_Mode =GPIO_Mode_Out_PP;  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(SOFTWARE_PORT_MOSI,&GPIO_InitStructure);

  SOFTWARE_CS_SET();
  SOFTWARE_SCLK_CLR();
  SOFTWARE_MOSI_SET();
}

/*******************************************************************************
* FunctionName   : void Div_SpiSoftware_Write_Byte(U8 dat)
* Description    : дһ���ֽ�����
* EntryParameter : 
* ReturnValue    : 
********************************************************************************/

/*/mode 0*/

void Div_SpiSoftware_Write_Byte(U8 dat)
{
  U8 i = 0;

  for(i=0;i<8;i++)
  {
    if(dat&0x80)
    {
      SOFTWARE_MOSI_SET();	
    }
    else
    {
      SOFTWARE_MOSI_CLR();
    }
    SOFTWARE_SCLK_CLR();
    SOFTWARE_SCLK_SET();
    dat<<=1;
  }
  
  SOFTWARE_SCLK_CLR();//�ͷ�ʱ����
}

/*******************************************************************************
* FunctionName   : U8 Div_SpiSoftware_Read_Byte(void)
* Description    : ��һ���ֽ�����
* EntryParameter : 
* ReturnValue    : ���ص�����
********************************************************************************/

U8 Div_SpiSoftware_Read_Byte(void)
{
  U8 i = 0;
  U8 dat = 0;

  for(i=0;i<8;i++)
  {
    dat<<=1;
    if(SOFTWARE_MISO_TEST())
    {
      dat|=0x01;	
    }
    SOFTWARE_SCLK_SET();
    SOFTWARE_SCLK_CLR();
  }
  SOFTWARE_SCLK_CLR();//�ͷ�ʱ����
  
  return dat;
}

/*******************************************************************************
* FunctionName   : U8 Div_SpiSoftware_ReadWrite_Byte(U8 dat)
* Description    : ��дһ���ֽ�����
* EntryParameter : 
* ReturnValue    : ���ص�����
********************************************************************************/

U8 Div_SpiSoftware_ReadWrite_Byte(U8 dat)
{
  U8 i = 0;

  for(i=0;i<8;i++)
  {
    if(dat&0x80)
    {
      SOFTWARE_MOSI_SET();	
    }
    else
    {
      SOFTWARE_MOSI_CLR();
    }
    dat<<=1;
    if(SOFTWARE_MISO_TEST())
    {
       dat|=0x01;	
    }
    SOFTWARE_SCLK_SET();
    SOFTWARE_SCLK_CLR();
  }
  
  SOFTWARE_SCLK_CLR();//�ͷ�ʱ����
  
  return dat;
}

/*******************************************************************************
* FunctionName   : void Div_SpiSoftware_Write_halfword(U16 dat)
* Description    : д���������
* EntryParameter : 
* ReturnValue    : 
********************************************************************************/

void Div_SpiSoftware_Write_halfword(U16 dat)
{
  Div_SpiSoftware_Write_Byte((dat& 0xFF00) >> 8);
  Div_SpiSoftware_Write_Byte(dat & 0xFF);
}

/*******************************************************************************
* FunctionName   : U16 Div_SpiSoftware_Read_halfword(void)
* Description    : �����������
* EntryParameter : 
* ReturnValue    : ���ص�����
********************************************************************************/

U16 Div_SpiSoftware_Read_halfword(void)
{
  U8 dat_h = 0,dat_l = 0;
  
  dat_h = Div_SpiSoftware_Read_Byte();
  dat_l = Div_SpiSoftware_Read_Byte();
  
  return (dat_h<<8|dat_l);
}

/*******************************************************************************
* FunctionName   : U16 Div_SpiSoftware_ReadWrite_Byte(U16 dat)
* Description    : ��д���������
* EntryParameter : 
* ReturnValue    : ���ص�����
********************************************************************************/

U16 Div_SpiSoftware_ReadWrite_halfword(U16 dat)
{
  U8 dat_h = 0,dat_l = 0;
  
  dat_h = Div_SpiSoftware_ReadWrite_Byte((dat& 0xFF00) >> 8);
  dat_l = Div_SpiSoftware_ReadWrite_Byte(dat & 0xFF);
  
  return (dat_h<<8|dat_l);
}

#endif