/*  
*key.c V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : �����ײ����
*
*
*/

/*######################################ͷ�ļ�##################################*/

#include "../Includes/header_config.h"

/*######################################����˵��################################*/
/*
	num  ��   ��  ��   ��   ȷ�� �˳�
	1    PA0  PA1 PA4  PA5  PA6  PA7
*
* ��Чʹ�÷�Χ ��Ӧ���ŵĵͰ�λ!!!!
*
* STM32F103C8           num 1       
* STM32F103RC           num 1
*/

/*######################################ȫ�ֱ���################################*/

U8 KEY_Trg = 0XFF; 
U8 KEY_Count = 0XFF;

/*######################################����ʵ��################################*/

/*******************************************************************************
* FunctionName   : void Div_Key_Init(void)
* Description    : ������ʼ��
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_Key_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  RCC_APB2PeriphClockCmd(KEY_CLK_PIN,ENABLE);

  GPIO_InitStructure.GPIO_Pin = KEY_PIN_0|KEY_PIN_1|KEY_PIN_2|KEY_PIN_3|KEY_PIN_4|KEY_PIN_5; 
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;  
  GPIO_Init(KEY_PORT_PIN,&GPIO_InitStructure);	
  
  GPIO_SetBits(KEY_PORT_PIN,KEY_PIN_0);
  GPIO_SetBits(KEY_PORT_PIN,KEY_PIN_1);
  GPIO_SetBits(KEY_PORT_PIN,KEY_PIN_2);
  GPIO_SetBits(KEY_PORT_PIN,KEY_PIN_3);
  GPIO_SetBits(KEY_PORT_PIN,KEY_PIN_4);
  GPIO_SetBits(KEY_PORT_PIN,KEY_PIN_5);
}

/*******************************************************************************
* FunctionName   : void KeyRead(void) 
* Description    : ������ȡ����
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_Key_Read(void) 
{
  uint8_t ReadData = 0XFF;
  
  ReadData=((KEY_PORT_PIN->IDR^0XFF)); 
  KEY_Trg = ReadData & (ReadData ^ KEY_Count); 
  KEY_Count = ReadData; 	
}

/*******************************************************************************
* FunctionName   : U8 key_scan(void)
* Description    : ������������
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

U8 Div_key_scan(void)
{
  Div_Key_Read();

  if (KEY_Trg & KEY_0) { return 0x01; }   
  if (KEY_Trg & KEY_1) { return 0x02; }
  if (KEY_Trg & KEY_2) { return 0x03; }
  if (KEY_Trg & KEY_3) { return 0x04; }
  if (KEY_Trg & KEY_4) { return 0x05; }
  if (KEY_Trg & KEY_5) { return 0x06; } 

  return 0x00;
}


