/*  
*dma_flash.h V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : flash_DMA�ײ����
*
*
*/

#ifndef __DMA_FLASH_H__
#define __DMA_FLASH_H__

#include "../Includes/type.h"

/*######################################�궨��##################################*/

#define SPI1_DMA_TX_CH          DMA1_Channel3
#define SPI1_DMA_RX_CH          DMA1_Channel2
            
#define SPI2_DMA_TX_CH          DMA1_Channel5
#define SPI2_DMA_RX_CH          DMA1_Channel4

#define SPI2_DMA_TXFLAG         DMA1_FLAG_GL5
#define SPI2_DMA_RXFLAG         DMA1_FLAG_GL4

#define SPI1_DMA_CLK            RCC_AHBPeriph_DMA1
#define SPI2_DMA_CLK            RCC_AHBPeriph_DMA1

#define SPI1_ADDR               (SPI1->DR)
#define SPI2_ADDR               (SPI2->DR)

/*######################################ö��####################################*/

typedef enum
{
  //SPI1_DMA = 0X00,
  SPI2_DMA = 0X00,
  SPI_DMA_MAX,
  
}SPI_DMA_LIST;

/*######################################�ṹ��##################################*/

#if (SPI_DMA_EN == 1) && (SPI_DMA_NUM_MAX>0)

/*SPI_DMA����ṹ��*/

typedef struct
{
  U8 spi_dma_txbuff[SPI_DMA_SIZE_MAX];//��������
  U8 spi_dma_rxbuff[SPI_DMA_SIZE_MAX];//��������
}SPI_DMA_DATA_LIST;

extern SPI_DMA_DATA_LIST spi_dma_data_list[SPI_DMA_NUM_MAX];

#endif

/*######################################����SPI.C����###########################*/


/*######################################ָ���################################*/


/*######################################�ⲿ����################################*/


/*######################################�ڲ���������##########################*/

/*######################################��ʼ����������##########################*/
#if (SPI_DMA_EN == 1) && (SPI_DMA_NUM_MAX>0)

extern void Div_dma_flash_Init(U32 buff_size);

#endif
/*######################################����ú�������##########################*/

#endif

/*######################################## END OF FILE #########################*/

