/*  
*w25qxx.h V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : W25QXX�ײ����
*
*
*/

#ifndef __W25QXX_H__
#define __W25QXX_H__

#include "../Includes/type.h"

/*######################################�궨��##################################*/

#define W25QXX_PAGE_SIZE                   256

/*######################################����SPI.C����###########################*/

#define Div_W25qxx_Cs_H()     GPIO_SetBits(SPI_PORT_CS2,SPI_PIN_CS2)    
#define Div_W25qxx_Cs_L()     GPIO_ResetBits(SPI_PORT_CS2,SPI_PIN_CS2)  

#define Div_W25qxx_Write(dat) Div_Spi_Write_Byte(T_SPI2,dat)
#define Div_W25qxx_Read()     Div_Spi_Read_Byte(T_SPI2)

/*######################################ָ���################################*/

#define W25QXX_WRITE_ENABLE              (0X06)
#define W25QXX_WRITE_DISABLE             (0X04)

#define W25QXX_READ_STATUS_REG1           (0X05)
#define W25QXX_READ_STATUS_REG2           (0X35)
#define W25QXX_WRITE_STATUS_REG           (0X01)

#define W25QXX_READ_DATA                 (0X03)
#define W25QXX_FAST_READ                 (0X0B)
#define W25QXX_PAGE_PROGRAM              (0X02)

#define W25QXX_SECTOR_ERASE              (0X20)
#define W25QXX_32K_SECTOR_ERASE          (0X54)
#define W25QXX_64K_SECTOR_ERASE          (0XD8)
#define W25QXX_CHIP_ERASE                (0XC7)

#define W25QXX_ERASE_SUSPEND             (0X75)
#define W25QXX_ERASE_RESUME              (0X7A)

#define W25QXX_POWER_DOWN                (0XB9)
#define W25QXX_POWER_RESEASE             (0XAB)

#define W25QXX_DRVICE_ID                 (0XAB)
#define W25QXX_READ_MANUF                (0X90)
#define W25QXX_JEDEC_ID                  (0X9F)
#define W25QXX_Read_Unique_ID            (0X4B)

/*######################################�ⲿ����################################*/

typedef enum
{
  SECTOR_4K  = 0X00,
  SECTOR_32K = 0X01,
  SECTOR_64K = 0X02,
  SECTOR_MAX,
}W25QXX_SECTOR;

typedef enum
{
  SPI_W25QXX_1 = 0X00,
  SPI_W25QXX_2 = T_SPI2,
  SPI_W25QXX_MAX,
  
}SPI_W25QXX_LIST;

/*######################################�ڲ���������##########################*/
void Div_W25qxx_Write_Enable(void);
void Div_W25qxx_Write_Disable(void);

U8 Div_W25qxx_Read_Status1(void);
U8 Div_W25qxx_Read_Status2(void);

void Div_W25qxx_Write_Status(U8 dat);

void Div_W25qxx_Addr_24Bit(U32 addr);

void Div_W25qxx_Check_Busy(void);

/*######################################��ʼ����������##########################*/

extern void Div_W25qxx_Init(void);

/*######################################����ú�������##########################*/

extern void Div_W25qxx_Erase_Suspend(void);
extern void Div_W25qxx_Erase_Resume(void);

extern void Div_W25qxx_Power_Down(void);
extern void Div_W25qxx_Power_Resease(void);

extern U8 Div_W25qxx_Device_ID(void);
extern U8 Div_W25qxx_Read_Manuf(void);
extern U16 Div_W25qxx_Jedec_ID(void);
extern void Div_W25qxx_Read_UniqueID(U8 *pdat);

extern void Div_W25qxx_Erase(U8 mode,U32 addr);
extern void Div_W25qxx_Sector_MoreErase(U8 mode,U32 start_addr,U32 stop_addr);
extern void Div_W25qxx_Chip_Erase(void);

extern U8 Div_W25qxx_Read_Data(U8 mode,U32 addr);
extern U8 Div_W25qxx_FastRead_Data(U8 mode,U32 addr);

extern void Div_W25qxx_Read_MoreData(U8 mode,U32 addr,U32 num,U8 *pdat);
extern void Div_W25qxx_FastRead_MoreData(U8 mode,U32 addr,U32 num,U8 *pdat);

extern void Div_W25qxx_Write_PageData(U32 addr,U32 num,U8 *pdat);
extern void Div_W25qxx_Write_PageData_2(U8 mode,U32 addr,U32 num,U8 *pdat);

extern void Div_W25qxx_Write_MorePageData(U8 mode,U32 addr,U32 num,U8 *pdat);

#endif

/*######################################## END OF FILE #########################*/

