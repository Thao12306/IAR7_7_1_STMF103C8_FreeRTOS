/*  
*w25qxx.c V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : W25QXX�ײ����
*
*
*/

/*######################################ͷ�ļ�##################################*/

#include "../Includes/header_config.h"

/*######################################����˵��################################*/
/*
          num     Name    Pin        Pin_STATE   
          1       W25QXX  /WP(3)     ͨ�����������VCC        
          2       W25QXX  /HOLD(7)   ͨ�����������VCC  
          
         ����
         num        Pin_CS  Pin_SCLK  Pin_MISO  Pin_MOSI
         оƬ���   1       6         2         5
*
* ��Чʹ�÷�Χ
*
* STM32F103C8           num 1/2      
* STM32F103RC           num 1/2
*/

/*######################################ȫ�ֱ���################################*/



/*######################################����ʵ��################################*/

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Init(void)
* Description    : ��ʼ��
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_W25qxx_Init(void)
{

}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Write_Enable(void)
* Description    : дʹ��
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_W25qxx_Write_Enable(void)
{
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_WRITE_ENABLE);
  Div_W25qxx_Cs_H();
}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Write_Disable(void)
* Description    : дʹ�ܹر�
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_W25qxx_Write_Disable(void)
{
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_WRITE_DISABLE);
  Div_W25qxx_Cs_H();
}

/*******************************************************************************
* FunctionName   : U8 Div_W25qxx_Read_Status1(void)
* Description    : ��״̬�Ĵ���
* EntryParameter : ��
* ReturnValue    : ���ص�����
********************************************************************************/

U8 Div_W25qxx_Read_Status1(void)
{
  U8 dat = 0;
  
  Div_W25qxx_Cs_L();  
  Div_W25qxx_Write(W25QXX_READ_STATUS_REG1);
  dat = Div_W25qxx_Read();
  Div_W25qxx_Cs_H();
  
  return dat;
}

/*******************************************************************************
* FunctionName   : U8 Div_W25qxx_Read_Status2(void)
* Description    : ��״̬�Ĵ���
* EntryParameter : ��
* ReturnValue    : ���ص�����
********************************************************************************/

U8 Div_W25qxx_Read_Status2(void)
{
  U8 dat = 0;
  
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_READ_STATUS_REG2);
  dat = Div_W25qxx_Read();
  Div_W25qxx_Cs_H();
  
  return dat;
}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Check_Busy(void)
* Description    : d�ȴ���æ
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_W25qxx_Check_Busy(void)
{
  while((Div_W25qxx_Read_Status1()&0X01)==0X01)
  {}
}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Write_Status(U8 dat)
* Description    : д״̬�Ĵ���
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

/*
(bits 7, 5, 4, 3, 2 of Status Register-1) and QE, 
SRP1(bits 9 and 8 of Status Register-2) can be written to
*/

void Div_W25qxx_Write_Status(U8 dat)
{
  Div_W25qxx_Write_Enable();
  
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_WRITE_STATUS_REG);
  Div_W25qxx_Write(dat);
  Div_W25qxx_Cs_H();
}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Addr_24Bit(U32 addr)
* Description    : ����24Bit��ַ
* EntryParameter : 24Bit��ַ
* ReturnValue    : ��
********************************************************************************/

void Div_W25qxx_Addr_24Bit(U32 addr)
{
  Div_W25qxx_Write(((addr&0XFFFFFF)>>16));
  Div_W25qxx_Write(((addr&0XFFFF)>>8));
  Div_W25qxx_Write(addr&0XFF);
}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Erase(U8 mode,U32 addr)
* Description    : ����ɾ�� 4K�ֽ� Ĭ��0XFF
* EntryParameter : 24Bit��ַ
* ReturnValue    : ��
********************************************************************************/

void Div_W25qxx_Erase(U8 mode,U32 addr)
{
  U32 temp_addr = 0;
  
  temp_addr = (mode>0)?(addr<<12):(addr);
  
  Div_W25qxx_Write_Enable();
  
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_SECTOR_ERASE);
  Div_W25qxx_Addr_24Bit(temp_addr);
  Div_W25qxx_Cs_H();
  
  Div_W25qxx_Check_Busy();
}
/*******************************************************************************
* FunctionName   : void Div_W25qxx_Erase(U8 mode,U8 num,U32 addr)
* Description    : �������ɾ�� 4KĬ��0XFF
* EntryParameter : 24Bit��ַ
* ReturnValue    : ��
********************************************************************************/

/*�����ֲ�
-------------   0X5FFF
-------------5
-------------4
-------------3
-------------2
-------------1 0X1000
-------------0
*/

void Div_W25qxx_Sector_MoreErase(U8 mode,U32 start_addr,U32 stop_addr)
{
  U32 temp_addr = 0;
  U32 temp_addr2 = 0;
  U32 temp_cnt = 0;
  U32 i = 0;
  
  temp_addr = (mode>0)?(start_addr<<12):(start_addr);
  temp_addr2 = (mode>0)?(stop_addr<<12):(stop_addr);
  
  temp_cnt = (((temp_addr2 - temp_addr)%4096)>0)?((temp_addr2 - temp_addr)/4096+1):((temp_addr2 - temp_addr)/4096);
  
  for(i=0;i<temp_cnt;i++)
  {
      
    Div_W25qxx_Write_Enable();
    
    Div_W25qxx_Cs_L();
    Div_W25qxx_Write(W25QXX_SECTOR_ERASE);
    Div_W25qxx_Addr_24Bit(temp_addr+i*4096);//ָ����һ������
    Div_W25qxx_Cs_H();
  
    Div_W25qxx_Check_Busy();
  
  } 
}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Chip_Erase(void)
* Description    : оƬɾ�� 
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_W25qxx_Chip_Erase(void)
{
  Div_W25qxx_Write_Enable();
  
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_CHIP_ERASE);
  Div_W25qxx_Cs_H();
  
  Div_W25qxx_Check_Busy();
}

/*******************************************************************************
* FunctionName   : U8 Div_W25qxx_Read_Data(U8 mode,U32 addr)
* Description    : ������
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

/*
*mode 1 ������ַ ֱ���� 0,1,2
*mode 0 ʵ�ʵ�ַ 0x0000-0x0FFF ����0 0x1000-0x1FFF ����1
*/

U8 Div_W25qxx_Read_Data(U8 mode,U32 addr)
{
  U8 temp_dat = 0;
  U32 temp_addr = 0;
  
  temp_addr = (mode>0) ? (addr<<12) : (addr);
  
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_READ_DATA);
  Div_W25qxx_Addr_24Bit(temp_addr);
  temp_dat = Div_W25qxx_Read();
  Div_W25qxx_Cs_H();
  
  return temp_dat; 
}

/*******************************************************************************
* FunctionName   : U8 Div_W25qxx_Read_MoreData(U32 addr)
* Description    : ���������
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

/*
*mode 1 ������ַ ֱ���� 0,1,2
*mode 0 ʵ�ʵ�ַ 0x0000-0x0FFF ����0 0x1000-0x1FFF ����1
*/

void Div_W25qxx_Read_MoreData(U8 mode,U32 addr,U32 num,U8 *pdat)
{
  U32 temp_addr = 0;
  
  SPI_InitTypeDef  SPI_InitStructure;//DMA
  
  if(!pdat)
  {}
  
#if (SPI_DMA_EN == 1) && (SPI_DMA_NUM_MAX>0)
  
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_RxOnly;
  SPI_Init(Spi_List[SPI_W25QXX_2], &SPI_InitStructure);
  
#endif
  
  temp_addr = (mode>0)? (addr<<12) : (addr);
  
  Div_W25qxx_Cs_L();
  
  Div_W25qxx_Write(W25QXX_READ_DATA);
  Div_W25qxx_Addr_24Bit(temp_addr);
  
#if (SPI_DMA_EN == 1) && (SPI_DMA_NUM_MAX>0)
  
  SPI_I2S_DMACmd(Spi_List[SPI_W25QXX_2], SPI_I2S_DMAReq_Rx, ENABLE);
  while(DMA_GetFlagStatus(SPI2_DMA_RXFLAG) == RESET);
  
#else
  
  while(num--)
  {
    *pdat = Div_W25qxx_Read();
    pdat++;
  }
  
#endif
  
  Div_W25qxx_Cs_H();

}

/*******************************************************************************
* FunctionName   : U8 Div_W25qxx_FastRead_Data(U8 mode,U32 addr)
* Description    : ���ٶ�ȡ����
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

/*
*mode 1 ������ַ ֱ���� 0,1,2
*mode 0 ʵ�ʵ�ַ 0x0000-0x0FFF ����0 0x1000-0x1FFF ����1
*/

U8 Div_W25qxx_FastRead_Data(U8 mode,U32 addr)
{
  U8 temp_dat = 0;
  U32 temp_addr = 0;
  
  temp_addr = (mode>0) ? (addr<<12) : (addr);
  
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_FAST_READ);
  Div_W25qxx_Addr_24Bit(temp_addr);
  Div_W25qxx_Write(0XFF);
  temp_dat = Div_W25qxx_Read();
  Div_W25qxx_Cs_H();
  
  return temp_dat; 
}

/*******************************************************************************
* FunctionName   : U8 Div_W25qxx_FastRead_MoreData(U32 addr,U32 num,U8 *Pdat)
* Description    : ���ٶ�ȡ�������
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

/*
*mode 1 ������ַ ֱ���� 0,1,2
*mode 0 ʵ�ʵ�ַ 0x0000-0x0FFF ����0 0x1000-0x1FFF ����1
*/

void Div_W25qxx_FastRead_MoreData(U8 mode,U32 addr,U32 num,U8 *pdat)
{
  U32 temp_addr = 0;
  
  SPI_InitTypeDef  SPI_InitStructure;//DMA
  
  if(!pdat)
  {}
  
#if (SPI_DMA_EN == 1) && (SPI_DMA_NUM_MAX>0)
  
  //SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_RxOnly;
  //SPI_Init(Spi_List[SPI_W25QXX_2], &SPI_InitStructure);
  
#endif
 
  temp_addr = (mode>0)? (addr<<12) : (addr);
  
  Div_W25qxx_Cs_L();
  
  Div_W25qxx_Write(W25QXX_FAST_READ);
  Div_W25qxx_Addr_24Bit(temp_addr);
  Div_W25qxx_Write(0XFF);
 
#if (SPI_DMA_EN == 1) && (SPI_DMA_NUM_MAX>0)
  
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_RxOnly;
  SPI_Init(Spi_List[SPI_W25QXX_2], &SPI_InitStructure);
  
  SPI_I2S_DMACmd(Spi_List[SPI_W25QXX_2], SPI_I2S_DMAReq_Rx, ENABLE);
  while(DMA_GetFlagStatus(SPI2_DMA_RXFLAG) == RESET);
  
#else
  
  while(num--)
  {
    *pdat = Div_W25qxx_Read();
    pdat++;
  }
  
#endif
  
  Div_W25qxx_Cs_H();
}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Write_PageData_2(U8 mode,U32 addr,U32 num,U8 *pdat)
* Description    : д���� 
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

/*
*mode 1 ������ַ ֱ���� 0,1,2
*mode 0 ʵ�ʵ�ַ 0x0000-0x0FFF ����0 0x1000-0x1FFF ����1
*/

/*
*һҳ���256������ ����Ὣǰ������ݸ���
*/

void Div_W25qxx_Write_PageData_2(U8 mode,U32 addr,U32 num,U8 *pdat)
{ 
  U32 temp_addr = 0;
  
  if(!pdat)
  {}
  
  if(!num)
  {}
  
  temp_addr = (mode>0)? (addr<<12) : (addr);
  
  if(num>W25QXX_PAGE_SIZE)
  {
    num = W25QXX_PAGE_SIZE;//��дһҳ
  }
  
  Div_W25qxx_Write_Enable();
  
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_PAGE_PROGRAM);
  Div_W25qxx_Addr_24Bit(temp_addr);
 
#if (SPI_DMA_EN == 1) && (SPI_DMA_NUM_MAX>0)
  
  SPI_I2S_DMACmd(Spi_List[SPI_W25QXX_2], SPI_I2S_DMAReq_Tx, ENABLE);
  while(DMA_GetFlagStatus(SPI2_DMA_TXFLAG) == RESET);
  
#else
  
  while(num--)
  {
    Div_W25qxx_Write(*pdat);
    pdat++;
  }
  
#endif
  
  Div_W25qxx_Cs_H();
  
  Div_W25qxx_Check_Busy();

}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Write_PageData(U32 addr,U32 num,U8 *pdat)
* Description    : д���� 
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

/*
*mode 1 ������ַ ֱ���� 0,1,2
*mode 0 ʵ�ʵ�ַ 0x0000-0x0FFF ����0 0x1000-0x1FFF ����1
*/

/*
*һҳ���256������ ����Ὣǰ������ݸ���
*/

void Div_W25qxx_Write_PageData(U32 addr,U32 num,U8 *pdat)
{ 
  if(!pdat)
  {}
  
  if(!num)
  {}
  if(num>W25QXX_PAGE_SIZE)
  {
    num = W25QXX_PAGE_SIZE;//��дһҳ
  }
  
  Div_W25qxx_Write_Enable();
  
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_PAGE_PROGRAM);
  Div_W25qxx_Addr_24Bit(addr);
  
#if (SPI_DMA_EN == 1) && (SPI_DMA_NUM_MAX>0)
  
  SPI_I2S_DMACmd(Spi_List[SPI_W25QXX_2], SPI_I2S_DMAReq_Tx, ENABLE);
  while(DMA_GetFlagStatus(SPI2_DMA_TXFLAG) == RESET);
  
#else
  
  while(num--)
  {
    Div_W25qxx_Write(*pdat);
    pdat++;
  }
  
#endif
  
  Div_W25qxx_Cs_H();
  
  Div_W25qxx_Check_Busy();
}
/*******************************************************************************
* FunctionName   : void Div_W25qxx_Write_MorePageData(U8 mode,U32 addr,U32 num,U8 *pdat)
* Description    : д���� 
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

/*
*mode 1 ������ַ ֱ���� 0,1,2
*mode 0 ʵ�ʵ�ַ 0x0000-0x0FFF ����0 0x1000-0x1FFF ����1
*/

void Div_W25qxx_Write_MorePageData(U8 mode,U32 addr,U32 num,U8 *pdat)
{ 
  U32 temp_addr = 0;
  
  U8 temp_addr_align = 0;//��ַ���� 256byte
  U8 left_count_to_align = 0;//����ٸ��ֽڿ���ҳ���� 0Ϊ����
  U8 temp_num_of_page = 0;//����ҳ
  U8 temp_num_of_singe = 0;//����һҳ������
  
  U8 temp = 0;
  
  if(!pdat)
  {}
  
  if(!num)
  {}
  
  temp_addr = (mode>0)? (addr<<12) : (addr);
  
  temp_addr_align = temp_addr % W25QXX_PAGE_SIZE;//256byte ����
  left_count_to_align = W25QXX_PAGE_SIZE - temp_addr_align;//b
  
  temp_num_of_page = num / W25QXX_PAGE_SIZE;
  temp_num_of_singe =  num % W25QXX_PAGE_SIZE;
  
  if(temp_addr_align == 0)//��ַ���� ���µ�һҳ��ʼд
  {
    if(temp_num_of_page == 0)//���ݲ���һҳ
    {
      Div_W25qxx_Write_PageData(temp_addr,num,pdat);
    }
    else//����һҳ
    {
      while(temp_num_of_page--)
      {
         Div_W25qxx_Write_PageData(temp_addr,W25QXX_PAGE_SIZE,pdat);
         temp_addr += W25QXX_PAGE_SIZE;
         pdat += W25QXX_PAGE_SIZE;
      }
      Div_W25qxx_Write_PageData(temp_addr,temp_num_of_singe,pdat);
    }
  }
  else //��ַ������
  {
    if(temp_num_of_page == 0)//���ݲ���һҳ
    {
      if(temp_num_of_singe>left_count_to_align)//Ҫд������ݴ���һҳʣ��Ŀռ�
      {
        temp = temp_num_of_singe - left_count_to_align;//��Ҫ�µ�һҳ�Ŀռ�
          
        //��д����ǰ�Ŀռ�  
        Div_W25qxx_Write_PageData(temp_addr,left_count_to_align,pdat);
        temp_addr += left_count_to_align;
        pdat += left_count_to_align;
        
        Div_W25qxx_Write_PageData(temp_addr,temp,pdat);
      }
      else//Ҫд�������С��һҳʣ��Ŀռ�
      {
        Div_W25qxx_Write_PageData(temp_addr,num,pdat);
      }
    }
    else//���ݳ�����һҳ
    {
      num = num - left_count_to_align;//��һҳ��Ҫ��������
      temp_num_of_page = num / W25QXX_PAGE_SIZE;
      temp_num_of_singe =  num % W25QXX_PAGE_SIZE;
      
      //��д����ǰ�Ŀռ�  
      Div_W25qxx_Write_PageData(temp_addr,left_count_to_align,pdat);
      temp_addr += left_count_to_align;
      pdat += left_count_to_align;
      
      while(temp_num_of_page--)
      {
         Div_W25qxx_Write_PageData(temp_addr,W25QXX_PAGE_SIZE,pdat);
         temp_addr += W25QXX_PAGE_SIZE;
         pdat += W25QXX_PAGE_SIZE;
      }
      
      if(temp_num_of_singe!=0)//�µ�һҳд����
      {
        Div_W25qxx_Write_PageData(temp_addr,temp_num_of_singe,pdat);
      }
    }
  }
}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Erase_Suspend(void)
* Description    : ��������
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

/*
Erase Suspend
is valid only during the sector or block erase operation.
*/

void Div_W25qxx_Erase_Suspend(void)
{
  Div_W25qxx_Write_Enable();
  
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_ERASE_SUSPEND);
  Div_W25qxx_Cs_H();
  
  Div_W25qxx_Check_Busy();
}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Erase_Resume(void)
* Description    : оƬɾ�� 
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_W25qxx_Erase_Resume(void)
{
  Div_W25qxx_Write_Enable();
  
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_ERASE_RESUME);
  Div_W25qxx_Cs_H();
  
  Div_W25qxx_Check_Busy();
}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Power_Down(void)
* Description    : оƬ����
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_W25qxx_Power_Down(void)
{
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_POWER_DOWN);
  Div_W25qxx_Cs_H();
}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Power_Resease(void)
* Description    : оƬ����ָ�
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_W25qxx_Power_Resease(void)
{
  Div_W25qxx_Cs_L();
  Div_W25qxx_Write(W25QXX_POWER_RESEASE);
  Div_W25qxx_Cs_H();
}

/*******************************************************************************
* FunctionName   : U8 Div_W25qxx_Device_ID(void)
* Description    : ��ID
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

U8 Div_W25qxx_Device_ID(void)
{
  U8 temp = 0;
  
  Div_W25qxx_Cs_L();
  
  Div_W25qxx_Write(W25QXX_DRVICE_ID);
  Div_W25qxx_Write(0xFF);
  Div_W25qxx_Write(0xFF);
  Div_W25qxx_Write(0xFF);
  
  temp = Div_W25qxx_Read();

  Div_W25qxx_Cs_H();
  
  return temp;
 
}

/*******************************************************************************
* FunctionName   : U8 Div_W25qxx_Read_Manuf(void)
* Description    : ��ID
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

U8 Div_W25qxx_Read_Manuf(void)
{
  U8 temp = 0;
  
  Div_W25qxx_Cs_L();
  
  Div_W25qxx_Write(W25QXX_READ_MANUF);
  Div_W25qxx_Write(0X00);
  Div_W25qxx_Write(0X00);
  Div_W25qxx_Write(0X00);
  Div_W25qxx_Write(0XEF);
  temp = Div_W25qxx_Read();
  
  Div_W25qxx_Cs_H();
  
  return temp;
 
}

/*******************************************************************************
* FunctionName   : U8 Div_W25qxx_Jedec_ID(void)
* Description    : ��ID
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

U16 Div_W25qxx_Jedec_ID(void)
{
  U8 temp = 0;
  U8 temp2 = 0;
  
  Div_W25qxx_Cs_L();
  
  Div_W25qxx_Write(W25QXX_JEDEC_ID);
  Div_W25qxx_Write(0XEF);
  temp2 = Div_W25qxx_Read();
  temp = Div_W25qxx_Read();
  
  Div_W25qxx_Cs_H();
  
  return ((temp2<<8)|temp);
 
}

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Read_UniqueID(U8 *pdat)
* Description    : ��ID
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_W25qxx_Read_UniqueID(U8 *pdat)
{
  U8 i = 0;
  U8 temp = 0;
  
  if(!pdat)
  {}
  
  Div_W25qxx_Cs_L();
  
  Div_W25qxx_Write(W25QXX_Read_Unique_ID);
  Div_W25qxx_Write(0XFF);
  Div_W25qxx_Write(0XFF);
  Div_W25qxx_Write(0XFF);
  Div_W25qxx_Write(0XFF);
  
  for(i=0;i<8;i++)
  {
    temp = Div_W25qxx_Read();
    pdat[i] = temp;
  }
  
  Div_W25qxx_Cs_H();
 
}









