/*  
*spi.h V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : SPI�ײ����
*
*
*/

#ifndef __SPI_H__
#define __SPI_H__

#include "../Includes/type.h"

/*######################################���Ŷ���################################*/

#define SPI_PIN_CS1                    GPIO_Pin_4                    
#define SPI_PIN_SCLK1                  GPIO_Pin_5 
#define SPI_PIN_MISO1                  GPIO_Pin_6
#define SPI_PIN_MOSI1                  GPIO_Pin_7

#define SPI_PORT_CS1                   GPIOA                   
#define SPI_PORT_SCLK1                 GPIOA 
#define SPI_PORT_MISO1                 GPIOA
#define SPI_PORT_MOSI1                 GPIOA

#define SPI_CLK_1                     RCC_APB2Periph_SPI1 

#define SPI_CLK_CS1                   RCC_APB2Periph_GPIOA                   
#define SPI_CLK_SCLK1                 RCC_APB2Periph_GPIOA 
#define SPI_CLK_MISO1                 RCC_APB2Periph_GPIOA
#define SPI_CLK_MOSI1                 RCC_APB2Periph_GPIOA

#define SPI_PIN_CS2                    GPIO_Pin_12                    
#define SPI_PIN_SCLK2                  GPIO_Pin_13 
#define SPI_PIN_MISO2                  GPIO_Pin_14
#define SPI_PIN_MOSI2                  GPIO_Pin_15

#define SPI_PORT_CS2                   GPIOB                   
#define SPI_PORT_SCLK2                 GPIOB 
#define SPI_PORT_MISO2                 GPIOB
#define SPI_PORT_MOSI2                 GPIOB

#define SPI_CLK_2                     RCC_APB1Periph_SPI2 

#define SPI_CLK_CS2                   RCC_APB2Periph_GPIOB                   
#define SPI_CLK_SCLK2                 RCC_APB2Periph_GPIOB 
#define SPI_CLK_MISO2                 RCC_APB2Periph_GPIOB
#define SPI_CLK_MOSI2                 RCC_APB2Periph_GPIOB

#define SPI_PIN_CS3                    GPIO_Pin_15                    
#define SPI_PIN_SCLK3                  GPIO_Pin_3 
#define SPI_PIN_MISO3                  GPIO_Pin_4
#define SPI_PIN_MOSI3                  GPIO_Pin_5

#define SPI_PORT_CS3                   GPIOA                   
#define SPI_PORT_SCLK3                 GPIOB 
#define SPI_PORT_MISO3                 GPIOB
#define SPI_PORT_MOSI3                 GPIOB

#define SPI_CLK_3                     RCC_APB1Periph_SPI3 

#define SPI_CLK_CS3                   RCC_APB2Periph_GPIOA                   
#define SPI_CLK_SCLK3                 RCC_APB2Periph_GPIOB 
#define SPI_CLK_MISO3                 RCC_APB2Periph_GPIOB
#define SPI_CLK_MOSI3                 RCC_APB2Periph_GPIOB

#if SOFTWARE_SPI_EN == 1

/*Ĭ��ģ��SPI�ӿ�ΪӲ��SPI2�ӿ�*/

#define SOFTWARE_PIN_CS                    GPIO_Pin_12                    
#define SOFTWARE_PIN_SCLK                  GPIO_Pin_13 
#define SOFTWARE_PIN_MISO                  GPIO_Pin_14
#define SOFTWARE_PIN_MOSI                  GPIO_Pin_15

#define SOFTWARE_PORT_CS                   GPIOB                   
#define SOFTWARE_PORT_SCLK                 GPIOB 
#define SOFTWARE_PORT_MISO                 GPIOB
#define SOFTWARE_PORT_MOSI                 GPIOB

#define SOFTWARE_CLK_CS                   RCC_APB2Periph_GPIOB                   
#define SOFTWARE_CLK_SCLK                 RCC_APB2Periph_GPIOB 
#define SOFTWARE_CLK_MISO                 RCC_APB2Periph_GPIOB
#define SOFTWARE_CLK_MOSI                 RCC_APB2Periph_GPIOB

#define SOFTWARE_CS_SET()       GPIO_SetBits(SOFTWARE_PORT_CS,SOFTWARE_PIN_CS)
#define SOFTWARE_CS_CLR()       GPIO_ResetBits(SOFTWARE_PORT_CS,SOFTWARE_PIN_CS)

#define SOFTWARE_SCLK_SET()     GPIO_SetBits(SOFTWARE_PORT_SCLK,SOFTWARE_PIN_SCLK)
#define SOFTWARE_SCLK_CLR()     GPIO_ResetBits(SOFTWARE_PORT_SCLK,SOFTWARE_PIN_SCLK)

#define SOFTWARE_MISO_SET()     GPIO_SetBits(SOFTWARE_PORT_MISO,SOFTWARE_PIN_MISO)
#define SOFTWARE_MISO_CLR()     GPIO_ResetBits(SOFTWARE_PORT_MISO,SOFTWARE_PIN_MISO)
#define SOFTWARE_MISO_TEST()    GPIO_ReadInputDataBit(SOFTWARE_PORT_MISO,SOFTWARE_PIN_MISO)

#define SOFTWARE_MOSI_SET()     GPIO_SetBits(SOFTWARE_PORT_MOSI,SOFTWARE_PIN_MOSI)
#define SOFTWARE_MOSI_CLR()     GPIO_ResetBits(SOFTWARE_PORT_MOSI,SOFTWARE_PIN_MOSI)

#endif

/*######################################ö�ٶ���################################*/

typedef enum
{
  T_SPI1 = 0X00,
  T_SPI2 = 0X01,
  T_SPI3 = 0X02,
  T_SPI_MAX,
}T_SPI;

/*######################################�ⲿ����################################*/

extern SPI_TypeDef* Spi_List[];

/*######################################��ʼ����������##########################*/

extern U8 Div_Spi_Init(U8 num,U8 SPI_BaudRatePrescaler,U32 buff_size);

#if SOFTWARE_SPI_EN == 1

extern void Div_SpiSoftware_Init(void);

#endif

/*######################################����ú�������##########################*/

extern U8 Div_Spi_ReadWrite_Byte(U8 num,U8 dat);
extern U8 Div_Spi_Write_Byte(U8 num,U8 dat);
extern U8 Div_Spi_Read_Byte(U8 num);

extern U8 Div_Spi_Speed_Set(U8 num,U8 SPI_BaudRatePrescaler);

#if SOFTWARE_SPI_EN == 1

extern void Div_SpiSoftware_Write_Byte(U8 dat);
extern void Div_SpiSoftware_Write_halfword(U16 dat);

extern U8 Div_SpiSoftware_Read_Byte(void);
extern U16 Div_SpiSoftware_Read_halfword(void);

extern U8 Div_SpiSoftware_ReadWrite_Byte(U8 dat);
extern U16 Div_SpiSoftware_ReadWrite_halfword(U16 dat);

#endif

#endif

/*######################################## END OF FILE #########################*/

