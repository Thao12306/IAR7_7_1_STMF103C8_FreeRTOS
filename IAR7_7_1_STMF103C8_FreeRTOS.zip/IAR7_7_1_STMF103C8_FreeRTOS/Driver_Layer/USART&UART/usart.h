/*  
*usart.h V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : ���ڵײ����
*
*
*/

#ifndef __USART_H__
#define __USART_H__

#include "../Includes/type.h"
#include "../Includes/set_parameters.h"

/*######################################���Ŷ���################################*/

#define USART_PIN_RX1                   GPIO_Pin_10                    
#define USART_PIN_TX1                   GPIO_Pin_9 
#define USART_PORT_RX1                  GPIOA
#define USART_PORT_TX1                  GPIOA

#define USART_CLK_1                     RCC_APB2Periph_USART1 

#define USART_CLK_RX1                   RCC_APB2Periph_GPIOA                   
#define USART_CLK_TX1                   RCC_APB2Periph_GPIOA 

#define USART_PIN_RX2                   GPIO_Pin_3                    
#define USART_PIN_TX2                   GPIO_Pin_2 
#define USART_PORT_RX2                  GPIOA
#define USART_PORT_TX2                  GPIOA

#define USART_CLK_2                     RCC_APB1Periph_USART2 

#define USART_CLK_RX2                   RCC_APB2Periph_GPIOA                   
#define USART_CLK_TX2                   RCC_APB2Periph_GPIOA 

#define USART_PIN_RX3                   GPIO_Pin_11                    
#define USART_PIN_TX3                   GPIO_Pin_10 
#define USART_PORT_RX3                  GPIOB
#define USART_PORT_TX3                  GPIOB

#define USART_CLK_3                     RCC_APB1Periph_USART3 

#define USART_CLK_RX3                   RCC_APB2Periph_GPIOB                   
#define USART_CLK_TX3                   RCC_APB2Periph_GPIOB 

#if USART_F103C8_EN == 0

#define USART_PIN_RX4                   GPIO_Pin_11                    
#define USART_PIN_TX4                   GPIO_Pin_10 
#define USART_PORT_RX4                  GPIOC
#define USART_PORT_TX4                  GPIOC

#define USART_CLK_4                     RCC_APB1Periph_UART4 

#define USART_CLK_RX4                   RCC_APB2Periph_GPIOC                   
#define USART_CLK_TX4                   RCC_APB2Periph_GPIOC 

#define USART_PIN_RX5                   GPIO_Pin_2                    
#define USART_PIN_TX5                   GPIO_Pin_12 
#define USART_PORT_RX5                  GPIOD
#define USART_PORT_TX5                  GPIOC

#define USART_CLK_5                     RCC_APB1Periph_UART5 

#define USART_CLK_RX5                   RCC_APB2Periph_GPIOD                   
#define USART_CLK_TX5                   RCC_APB2Periph_GPIOC 

#endif

/*######################################ö�ٶ���################################*/

/*
*USART��ö��
*/

typedef enum
{
  T_USART1 = 0X00,
  T_USART2 = 0X01,
  T_USART3 = 0X02,
  T_UART4 =  0X03,
  T_UART5 =  0X04,
  T_USART_MAX,
}T_USART;

typedef enum
{
  T_USART_ERR_NONE = 0X00,              //û�д���
  T_USART_ERR_NULL = 0X01,              //��ָ�����
  T_USART_ERR_INVA = 0X02,              //��Ч��������
  T_USART_ERR_DATA = 0X03,              //���ݴ���
  T_USART_ERR_MAX,
  
}T_USART_ERR;

/*######################################�����嶨��##############################*/

/*
�ռ乲�� �����жϽ������ݳ���
*/

typedef union
{
  __packed struct
  {
    U8 REC1_OK_FLAG : 1;                //�������һ���ֽڱ�־
    U8 REC2_OK_FLAG : 1;
    U8 REC3_OK_FLAG : 1;
    U8 REC4_OK_FLAG : 1;
    U8 REC5_OK_FLAG : 1;
    U8 RESERVE      : 3;
  };
  
  U8 r_data;
  
}USART_REC_FLAG;

/*######################################�ṹ�嶨��##############################*/

/*
*���������жϽ������ݻ���
*/

typedef struct
{
  USART_REC_FLAG usart_rec_flag;        //���ձ�־
  U8 REC_DATA[USART_NUM_MAX];           //���ջ�����
  
}USART_REC;

/*######################################ȫ�ֱ���################################*/

extern USART_REC usart_rec;

/*######################################�ⲿ����################################*/

extern USART_TypeDef* Usart_List[];

/*######################################��ʼ����������##########################*/

extern U8 Div_Usart_Init(U8 num,U32 baud);

/*######################################����ú�������##########################*/

extern U8 Div_Usart_Send_Byte(U8 num,U8 dat);
extern U8 Div_Usart_Send_MoreByte(U8 num,U16 cnt,U8 *pdat);

extern U8 Div_Usart_Send_HarfWord(U8 num,U16 dat);

extern U8 Div_Usart_Send_String(U8 num,U8 *pdat);

extern U16 Div_Usart_Get_StringLen(U8 *pdat);

#endif

/*######################################## END OF FILE #########################*/

