/*  
*math_cal.h V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : 
*DebugTools     : 
*Description    : ��ѧ����
*
*
*/

#ifndef __MATH_CAL_H__
#define __MATH_CAL_H__

/*######################################UXX_TO_ARRAY############################*/

#define MATH_U16_TO_ARRAY(array,dat_in)   *(array+0) = ((U8)((dat_in&0XFFFF)>>8));\
                                          *(array+1) = ((U8)(dat_in&0XFF));

#define MATH_ARRAY_TO_U16(array)          (*(array+0)<<8) + (*(array+1)<<0)


/*######################################����ú�������##########################*/

extern U16 Data_Escape(U8 *pout,U8 *pin,U16 len);
extern U16 Data_UnEscape(U8 *pout,U8 *pin,U16 len);

/*######################################Application#############################*/



/*######################################Client##################################*/



/*######################################Other###################################*/



#endif

/*######################################## END OF FILE #########################*/

