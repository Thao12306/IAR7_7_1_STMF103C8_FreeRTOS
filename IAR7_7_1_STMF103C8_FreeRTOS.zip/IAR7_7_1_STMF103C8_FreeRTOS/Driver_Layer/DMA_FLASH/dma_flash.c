/*  
*dma_flash.c V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : flash_DMA�ײ����
*
*
*/

/*######################################ͷ�ļ�##################################*/

#include "../Includes/header_config.h"

/*######################################����˵��################################*/
/*
          num     Name          CH  

          1       SPI1_TX       MDA1_CH3        
          1       SPI1_RX       MDA1_CH2 

          2       SPI2_TX       MDA1_CH5        
          2       SPI2_RX       MDA1_CH4 

          3       SPI3_TX       ��       
          3       SPI3_RX       ��  
          
*
* ��Чʹ�÷�Χ
*
* STM32F103C8           num 1/2      
* STM32F103RC           num 1/2
*/

/*######################################ȫ�ֱ���################################*/

/*SPI_DMA����ṹ��*/

#if (SPI_DMA_EN == 1) && (SPI_DMA_NUM_MAX>0)

SPI_DMA_DATA_LIST spi_dma_data_list[SPI_DMA_NUM_MAX];

/*######################################����ʵ��################################*/

/*******************************************************************************
* FunctionName   : void Div_W25qxx_Init(void)
* Description    : ��ʼ��
* EntryParameter : ��
* ReturnValue    : ��
********************************************************************************/

void Div_dma_flash_Init(U32 buff_size)
{
  DMA_InitTypeDef DMA_InitStructure;

  RCC_AHBPeriphClockCmd(SPI2_DMA_CLK, ENABLE);

  DMA_Cmd(SPI2_DMA_TX_CH, DISABLE);      //�ر�DMA  
  DMA_DeInit(SPI2_DMA_TX_CH);            //�ָ���ʼֵ   

  DMA_InitStructure.DMA_PeripheralBaseAddr =(uint32_t)(&SPI2_ADDR);	
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)spi_dma_data_list[SPI2_DMA].spi_dma_txbuff;

  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;	
  DMA_InitStructure.DMA_BufferSize = buff_size;   

  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable; 
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;	

  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;	

  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;	 

  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium; 
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;

  DMA_Init(SPI2_DMA_TX_CH, &DMA_InitStructure);
  DMA_ClearFlag(SPI2_DMA_TXFLAG);         //������б�� 
  DMA_Cmd(SPI2_DMA_TX_CH, ENABLE);             //�ر�DMA 			
  //DMA_ITConfig(SPI2_DMA_TX_CH,DMA_IT_TC,ENABLE);//DMA�����ж� 
  
  //�������
  DMA_Cmd(SPI2_DMA_RX_CH, DISABLE);             //�ر�DMA  
  DMA_DeInit(SPI2_DMA_RX_CH);                   //�ָ���ʼֵ   

  DMA_InitStructure.DMA_PeripheralBaseAddr =(uint32_t)(&SPI2_ADDR);	
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)spi_dma_data_list[SPI2_DMA].spi_dma_rxbuff;

  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;	
  DMA_InitStructure.DMA_BufferSize = buff_size;   

  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable; 
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;	

  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;	

  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;	 

  DMA_InitStructure.DMA_Priority = DMA_Priority_Medium; 
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;

  DMA_Init(SPI2_DMA_RX_CH, &DMA_InitStructure);
  DMA_ClearFlag(SPI2_DMA_RXFLAG);         //������б��  
  DMA_Cmd(SPI2_DMA_RX_CH, ENABLE);              //ʹ��DMA 	
}

#endif 









