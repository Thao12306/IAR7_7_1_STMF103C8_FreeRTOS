/*  
*usart.c V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : ���ڵײ����
*
*
*/

/*######################################ͷ�ļ�##################################*/

#include "../Includes/header_config.h"

/*######################################����˵��################################*/
/*
          num     Name      Pin_RX     Pin_TX
          1       USART1    PA10       PA9
          2       USART2    PA3        PA2
          3       USART3    PB11       PB10
          4       UART4     PC11       PC10
          5       UART3     PD2        PC12
*
* ��Чʹ�÷�Χ
*
* STM32F103C8           num 1/2/3       
* STM32F103RC           num 1/2/3/4/5 
*/

/*######################################ȫ�ֱ���################################*/

#if USART_F103C8_EN == 1

USART_TypeDef* Usart_List[] = {USART1,USART2,USART3};

#else

USART_TypeDef* Usart_List[] = {USART1,USART2,USART3,UART4,UART5};

#endif


//�жϽ�������ר��
USART_REC usart_rec;

/*######################################����ʵ��################################*/

/*******************************************************************************
* FunctionName   : U8 Div_Usart_Select_Clock(U8 ch,U8 state)
* Description    : ѡ�񴮿�ʱ��
* EntryParameter : ���ڱ��
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Div_Usart_Select_Clock(U8 ch)
{
  switch(ch)
  {
    case T_USART1:
      {
        RCC_APB2PeriphClockCmd(USART_CLK_RX1,ENABLE);
        RCC_APB2PeriphClockCmd(USART_CLK_TX1,ENABLE);
        
        RCC_APB2PeriphClockCmd(USART_CLK_1, ENABLE);
        break;
      }
    case T_USART2:
      {
        RCC_APB2PeriphClockCmd(USART_CLK_RX2,ENABLE);
        RCC_APB2PeriphClockCmd(USART_CLK_TX2,ENABLE);
        
        RCC_APB1PeriphClockCmd(USART_CLK_2, ENABLE);
        break;
      }
    case T_USART3:
      {
        RCC_APB2PeriphClockCmd(USART_CLK_RX3,ENABLE);
        RCC_APB2PeriphClockCmd(USART_CLK_TX3,ENABLE);
        
        RCC_APB1PeriphClockCmd(USART_CLK_3, ENABLE);
        break;
      }
      
#if USART_F103C8_EN == 0
      
    case T_UART4:
      {
        RCC_APB2PeriphClockCmd(USART_CLK_RX4,ENABLE);
        RCC_APB2PeriphClockCmd(USART_CLK_TX4,ENABLE);
        
        RCC_APB1PeriphClockCmd(USART_CLK_4,  ENABLE);
        break;
      }
    case T_UART5:
      {
        RCC_APB2PeriphClockCmd(USART_CLK_RX5,ENABLE);
        RCC_APB2PeriphClockCmd(USART_CLK_TX5,ENABLE);
        
        RCC_APB1PeriphClockCmd(USART_CLK_5,  ENABLE);
        break;
      }
      
#endif
      
    default:return T_USART_ERR_INVA;break;
  }
  return T_USART_ERR_NONE;
}

/*******************************************************************************
* FunctionName   : U8 Div_Usart_Gpio_Set(U8 num)
* Description    : ���ô�������
* EntryParameter : ��������
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Div_Usart_Gpio_Set(U8 num)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  
  switch(num)
  {
    case T_USART1:
      {
        GPIO_InitStructure.GPIO_Pin = USART_PIN_TX1;  
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(USART_PORT_TX1, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin = USART_PIN_RX1;  
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
        GPIO_Init(USART_PORT_RX1, &GPIO_InitStructure);
        
        break;
      }
  
    case T_USART2:
      {
        GPIO_InitStructure.GPIO_Pin = USART_PIN_TX2;  
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(USART_PORT_TX2, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin = USART_PIN_RX2;  
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
        GPIO_Init(USART_PORT_RX2, &GPIO_InitStructure);
        
        break;
      }
      
    case T_USART3:
      {
        GPIO_InitStructure.GPIO_Pin = USART_PIN_TX3;  
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(USART_PORT_TX3, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin = USART_PIN_RX3;  
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
        GPIO_Init(USART_PORT_RX3, &GPIO_InitStructure);
       
        break;
      }
      
#if USART_F103C8_EN == 0
      
    case T_UART4:
      {
        GPIO_InitStructure.GPIO_Pin = USART_PIN_TX4;  
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(USART_PORT_TX4, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin = USART_PIN_RX4;  
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
        GPIO_Init(USART_PORT_RX4, &GPIO_InitStructure);
        
        break;
      }
      
    case T_UART5:
      {
        GPIO_InitStructure.GPIO_Pin = USART_PIN_TX5;  
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init(USART_PORT_TX5, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin = USART_PIN_RX5;  
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
        GPIO_Init(USART_PORT_RX5, &GPIO_InitStructure);
       
        break;
      }
      
#endif
      
    default:return T_USART_ERR_INVA;break;
    
  }
  
  return T_USART_ERR_NONE;
}

/*******************************************************************************
* FunctionName   : U8 Div_Usart_Set_RecNvic(U8 num)
* Description    : ���ô��ڽ����ж�
* EntryParameter : ���ںš�������
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

/*
Ĭ���жϷ���4
*/

U8 Div_Usart_Set_RecNvic(U8 num)
{
  NVIC_InitTypeDef NVIC_InitStructure;

  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
        
  switch(num)
  {
    case T_USART1:NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;break;
    case T_USART2:NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;break;
    case T_USART3:NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;break;
    
#if USART_F103C8_EN == 0
    
    case T_UART4 :NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn; break;
    case T_UART5 :NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn; break;
    
#endif
    
    default:return T_USART_ERR_INVA;break;
  }
  
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  return T_USART_ERR_NONE;
}

/*******************************************************************************
* FunctionName   : U8 Div_Usart_Set(USART_TypeDef* Usartx,U16 Baud)
* Description    : ���ô���
* EntryParameter : ���ںš�������
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Div_Usart_Set(U8 num,U32 baud)
{
  USART_InitTypeDef USART_InitStructure;
  
  if(!baud)return T_USART_ERR_INVA;
  
  USART_Cmd(Usart_List[num],DISABLE);
  
  USART_InitStructure.USART_BaudRate = baud;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(Usart_List[num],&USART_InitStructure);
  
#if USART_TC_IRQ_EN
  
  USART_ITConfig(Usart_List[num],USART_IT_TC,ENABLE);

#endif
  
#if USART_REC_IRQ_EN
  
   
  USART_ITConfig(Usart_List[num],USART_IT_RXNE,ENABLE); 
   
#endif  
  
#if USART_IDLE_IRQ_EN

  USART_ITConfig(Usart_List[num],USART_IT_IDLE,ENABLE);

#endif  
  
  USART_ClearFlag(Usart_List[num], USART_FLAG_TC|USART_FLAG_TXE|USART_FLAG_RXNE);
  
  USART_Cmd(Usart_List[num],ENABLE);
  
#if USART_DMA_EN == 1
  
  
  
#endif

  return T_USART_ERR_NONE;
}

/*******************************************************************************
* FunctionName   : U8 Div_Usart_Init(U8 num,U16 baud)
* Description    : ���ô���
* EntryParameter : ���ںš�������
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Div_Usart_Init(U8 num,U32 baud)
{
  if(!baud)return T_USART_ERR_INVA;
  
#if USART_NVIC_IRQ_EN == 1
  
  Div_Usart_Set_RecNvic(num);
  
#endif
  
#if USART_DMA_EN == 1
  
  Div_Dma_Usart_SetRecNvic(); 
  
#endif
  
  Div_Usart_Select_Clock(num);
  Div_Usart_Gpio_Set(num);
  Div_Usart_Set(num,baud);
  
#if USART_DMA_EN == 1
  
  USART_DMACmd(USART1, USART_DMAReq_Rx, ENABLE); 
  USART_DMACmd(USART1, USART_DMAReq_Tx, ENABLE); 
  
#endif
 
  return T_USART_ERR_NONE;
}

/*******************************************************************************
* FunctionName   : U8 Div_Usart_Send_Byte(U8 num,U8 dat)
* Description    : ����һ���ֽ�����
* EntryParameter : ���ںš�������
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Div_Usart_Send_Byte(U8 num,U8 dat)
{
  USART_ClearFlag(Usart_List[num], USART_FLAG_TC|USART_FLAG_TXE|USART_FLAG_RXNE);
  
  USART_SendData(Usart_List[num],((U8)(dat&0XFF)));
  while (USART_GetFlagStatus(Usart_List[num], USART_FLAG_TXE) == RESET);
  
  return T_USART_ERR_NONE;
}

/*******************************************************************************
* FunctionName   : U8 Div_Usart_Send_MoreByte(U8 num,U8 cnt,U8 *pdat)
* Description    : ���Ͷ���ֽ�����
* EntryParameter : ���ںš�������
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Div_Usart_Send_MoreByte(U8 num,U16 cnt,U8 *pdat)
{
  if(!cnt)
  {
    return T_USART_ERR_INVA;
  }
  
    if(!pdat)
  {
    return T_USART_ERR_NULL;
  }
  
  while(cnt--)
  {
    Div_Usart_Send_Byte(num,*pdat++);
  }
  
  return T_USART_ERR_NONE;
}

/*******************************************************************************
* FunctionName   : U8 Div_Usart_Send_HarfWord(U8 num,U16 dat)
* Description    : ����һ��16bit����
* EntryParameter : ���ںš�������
* ReturnValue    : 0���ɹ�������ֵ(ʧ��)
********************************************************************************/

U8 Div_Usart_Send_HarfWord(U8 num,U16 dat)
{
  Div_Usart_Send_Byte(num,((U8)((dat&0XFFFF)>>8)));
  Div_Usart_Send_Byte(num,((U8)(dat&0XFF)));
 
  return T_USART_ERR_NONE;
}

/*******************************************************************************
* FunctionName   : U8 Div_Usart_Send_String(U8 num,U8 *pdat)
* Description    : �����ַ���������ֵ
* EntryParameter : ���ںš�ָ��
* ReturnValue    : 0���ɹ�������ֵ(ʧ��) �ַ�������
********************************************************************************/

U8 Div_Usart_Send_String(U8 num,U8 *pdat)
{
  if(!pdat)
  {
   return T_USART_ERR_NULL;
  }
  
  while(*pdat!='\0')
  {
    Div_Usart_Send_Byte(num,*pdat);
    pdat++;
  }

  return 0;
}

/*******************************************************************************
* FunctionName   : U16 Div_Usart_Get_StringLen(U8 *pdat)
* Description    : �ַ�������
* EntryParameter : ָ��
* ReturnValue    : 0���ɹ�������ֵ(ʧ��) �ַ�������
********************************************************************************/

U16 Div_Usart_Get_StringLen(U8 *pdat)
{
  U16 len = 0;
  
  if(!pdat)
  {
    return T_USART_ERR_NULL;
  }

  while(*pdat!='\0')
  {
    pdat++;
    len++;
  }

  return len;
}

/*******************************************************************************
* FunctionName   : 
* Description    : �����жϷ������
* EntryParameter : 
* ReturnValue    : 
********************************************************************************/

#if USART_NVIC_IRQ_EN == 1

#if USART_DMA_EN == 1

/*USART3 RX IDLE �ж�*/
void USART3_IRQHandler(void)
{
  uint8_t Length = Length;

  if(USART_GetITStatus(USART1, USART_IT_IDLE) != RESET)
  {
    DMA_Cmd(DMA1_Channel5, DISABLE);            //�ر�DMA 
    DMA_ClearFlag(DMA1_FLAG_GL5);               //�����־

    Length = USART1->SR;                        //���USART_IT_IDLE��־
    Length = USART1->DR;

    DMA1_Channel5->CNDTR = RXBUFF_SIZE;  
    DMA_Cmd(DMA1_Channel5, ENABLE);      
  }
}  

#else 

void USART1_IRQHandler(void)
{
  U8 dat = 0;
  
  if(USART_GetFlagStatus(Usart_List[T_USART1], USART_FLAG_ORE) != RESET)//����������
  {
    USART_ReceiveData(Usart_List[T_USART1]);
  }
  if(USART_GetITStatus(Usart_List[T_USART1], USART_IT_RXNE) != RESET)
  {
    USART_ClearITPendingBit(Usart_List[T_USART1], USART_IT_RXNE);
    dat = USART_ReceiveData(Usart_List[T_USART1]);
    Link_Alter_Write_Dat(LINK_DIV_NUM,COMM_TASK_NUM,dat);
    //Div_Usart_Send_Byte(T_USART1,dat);
    //usart_rec.REC_DATA[T_USART1] = dat;
    //usart_rec.usart_rec_flag.REC1_OK_FLAG= 1;
  }
}

#endif

void USART2_IRQHandler(void)
{
  U8 dat = 0;
   
  if(USART_GetFlagStatus(Usart_List[T_USART2], USART_FLAG_ORE) != RESET)//����������
  {
    USART_ReceiveData(Usart_List[T_USART2]);
  }
  if(USART_GetITStatus(Usart_List[T_USART2], USART_IT_RXNE) != RESET)
  {
    USART_ClearITPendingBit(Usart_List[T_USART2], USART_IT_RXNE);
    dat = USART_ReceiveData(Usart_List[T_USART2]);
    usart_rec.REC_DATA[T_USART2] = dat;
    usart_rec.usart_rec_flag.REC2_OK_FLAG= 1;
  }
}

void USART3_IRQHandler(void)
{
  U8 dat = 0;
   
  if(USART_GetFlagStatus(Usart_List[T_USART3], USART_FLAG_ORE) != RESET)//����������
  {
    USART_ReceiveData(Usart_List[T_USART3]);
  }
  if(USART_GetITStatus(Usart_List[T_USART3], USART_IT_RXNE) != RESET)
  {
    USART_ClearITPendingBit(Usart_List[T_USART3], USART_IT_RXNE);
    dat = USART_ReceiveData(Usart_List[T_USART3]);
    usart_rec.REC_DATA[T_USART3] = dat;
    usart_rec.usart_rec_flag.REC3_OK_FLAG= 1;
  }
}

#if USART_F103C8_EN == 0

void UART4_IRQHandler(void)
{
   U8 dat = 0;
   
  if(USART_GetFlagStatus(Usart_List[T_UART4], USART_FLAG_ORE) != RESET)//����������
  {
    USART_ReceiveData(Usart_List[T_UART4]);
  }
  if(USART_GetITStatus(Usart_List[T_UART4], USART_IT_RXNE) != RESET)
  {
    USART_ClearITPendingBit(Usart_List[T_UART4], USART_IT_RXNE);
    dat = USART_ReceiveData(Usart_List[T_UART4]);
    usart_rec.REC_DATA[T_UART4] = dat;
    usart_rec.usart_rec_flag.REC4_OK_FLAG= 1;
  }
}

void UART5_IRQHandler(void)
{
  U8 dat = 0;
   
  if(USART_GetFlagStatus(Usart_List[T_UART5], USART_FLAG_ORE) != RESET)//����������
  {
    USART_ReceiveData(Usart_List[T_UART5]);
  }
  if(USART_GetITStatus(Usart_List[T_UART5], USART_IT_RXNE) != RESET)
  {
    USART_ClearITPendingBit(Usart_List[T_UART5], USART_IT_RXNE);
    dat = USART_ReceiveData(Usart_List[T_UART5]);
    usart_rec.REC_DATA[T_UART5] = dat;
    usart_rec.usart_rec_flag.REC5_OK_FLAG= 1;
  }
  
}

#endif

#endif

/*******************************************************************************
* FunctionName   : 
* Description    : printf scanfʵ��
* EntryParameter : 
* ReturnValue    : 
********************************************************************************/

/*1 ָ��һ��������Ϊ���Խӿ�
  2 ��ѡLirary full
*/

int fputc(int ch, FILE *f)
{
  USART_ClearFlag(Usart_List[T_USART1], USART_FLAG_TC|USART_FLAG_TXE|USART_FLAG_RXNE);
  
  USART_SendData(Usart_List[T_USART1],((U8)(ch&0XFF)));
  while (USART_GetFlagStatus(Usart_List[T_USART1], USART_FLAG_TXE) == RESET);	
  return (ch);
}

int fgetc(FILE *f)
{
  USART_ClearFlag(Usart_List[T_USART1], USART_FLAG_TC|USART_FLAG_TXE|USART_FLAG_RXNE);
  
  while (USART_GetFlagStatus(Usart_List[T_USART1], USART_FLAG_RXNE) == RESET);
  return (int)USART_ReceiveData(Usart_List[T_USART1]);
}




