/*  
*ft_comm.c V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : �����м�����(ͨ��Э��)
*
*
*/

/*######################################ͷ�ļ�##################################*/

#include "../Includes/header_config.h"

/*######################################ȫ�ֱ���################################*/

/*���ݻ���*/

FTCOMM_DATA_LIST ftcomm_data_list[FTCMM_NUM];

/*֡��ʽ�ж�*/

FTCOMM_FRAME_LIST comm_frame_list;

/*######################################����ʵ��################################*/

/*******************************************************************************
* FunctionName   : void Link_WirteLQueue_DatFunc(U8 num,U8 dat)
* Description    : д������
* EntryParameter : ͨ�ű�š�д������
* ReturnValue    : �������
********************************************************************************/

void Link_WirteLQueue_Dat(U8 num,U8 dat)
{
  Loop_Queue_Push(&loop_queue_list[num],&dat,1);
}

/*******************************************************************************
* FunctionName   : void Link_ReadLQueue_Dat(U8 num,U8 dat)
* Description    : ��������
* EntryParameter : ͨ�ű�š���������
* ReturnValue    : �������
********************************************************************************/

U8 Link_ReadLQueue_Dat(U8 num,U8 dat)
{
  Loop_Queue_Pop(&loop_queue_list[num],&dat,1);
  
  return FTCOMM_ERR_NONE;  
}

/*******************************************************************************
* FunctionName   : U16 Link_GetLQueue_len(U8 num)
* Description    : ��ȡ���ݳ���
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

U16 Link_GetLQueue_len(U8 num)
{
  U16 temp_len = 0;
  
  temp_len = Loop_Get_Queue_len(&loop_queue_list[num]);
  
  return temp_len;
}

/*�����������������ݽṹ�洢�� ����д����ȡ���ȴ���*/


/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$�����ļ�-Div$$$*/

/*******************************************************************************
* FunctionName   : U8 Link_Wirte_Dat(U8 num,U8 dat)
* Description    : д������
* EntryParameter : ͨ�ű�š�д������
* ReturnValue    : �������
********************************************************************************/

/*˫ָ�����*/

U8 Link_Wirte_Dat(U8 num,U8 dat)
{
  
  if(num>FTCMM_NUM)//ͨ����Ŀ�ж�
  {
    return FTCOMM_ERR_INVA;
  }
  
  if(ftcomm_data_list[num].rw_buff == NULL)//��д������Ϊ��
  {
    return FTCOMM_ERR_NULL;
  }
  
  ftcomm_data_list[num].rw_buff[ftcomm_data_list[num].w_pointer] = dat;//���ݴ���
  
  if(++ftcomm_data_list[num].w_pointer>ftcomm_data_list[num].rw_size)//������������С
  {
    ftcomm_data_list[num].w_pointer = 0;//ָ����0
  }

  return FTCOMM_ERR_NONE;
}

/*******************************************************************************
* FunctionName   : U8 Link_Wirte_MoreDat(U8 num,U8 *pdat,U16 len)
* Description    : д��������
* EntryParameter : ͨ�ű�š�д�����ݡ�����
* ReturnValue    : �������
********************************************************************************/

/*˫ָ�����*/

U8 Link_Wirte_MoreDat(U8 num,U8 *pdat,U16 len)
{
  U16 i = 0;

  if(num>FTCMM_NUM)//ͨ����Ŀ�ж�
  {
    return FTCOMM_ERR_INVA;
  }
  
  if(ftcomm_data_list[num].rw_buff == NULL)//��д������Ϊ��
  {
    return FTCOMM_ERR_NULL;
  }
  
  for(i=0;i<len;i++)
  {
    ftcomm_data_list[num].rw_buff[ftcomm_data_list[num].w_pointer] = *(pdat+i);//���ݴ���
    
    if(++ftcomm_data_list[num].w_pointer>ftcomm_data_list[num].rw_size)//������������С
    {
      ftcomm_data_list[num].w_pointer = 0;//ָ����0
    }
  }

  return FTCOMM_ERR_NONE;
}

/*******************************************************************************
* FunctionName   : U8 Link_Read_Dat(U8 num,U8 dat)
* Description    : ��������
* EntryParameter : ͨ�ű�š���������
* ReturnValue    : �������
********************************************************************************/

/*˫ָ�����*/

U8 Link_Read_Dat(U8 num,U8 *dat)
{
  
  if(num>FTCMM_NUM)//ͨ����Ŀ�ж�
  {
    return FTCOMM_ERR_INVA;
  }
  
  if(ftcomm_data_list[num].rw_buff == NULL)//��д������Ϊ��
  {
    return FTCOMM_ERR_NULL;
  }
  
  *dat = ftcomm_data_list[num].rw_buff[ftcomm_data_list[num].r_pointer];//���ݶ���
  
  if(++ftcomm_data_list[num].r_pointer>ftcomm_data_list[num].rw_size)//������������С
  {
    ftcomm_data_list[num].r_pointer = 0;//ָ����0
  }

  return FTCOMM_ERR_NONE;
}

/*******************************************************************************
* FunctionName   : U8 Link_Wirte_MoreDat(U8 num,U8 *pdat,U16 len)
* Description    : д��������
* EntryParameter : ͨ�ű�š�д�����ݡ�����
* ReturnValue    : �������
********************************************************************************/

/*˫ָ�����*/

U8 Link_Read_MoreDat(U8 num,U8 *pdat,U16 len)
{
  U16 i = 0;

  if(num>FTCMM_NUM)//ͨ����Ŀ�ж�
  {
    return FTCOMM_ERR_INVA;
  }
  
  if(ftcomm_data_list[num].rw_buff == NULL)//��д������Ϊ��
  {
    return FTCOMM_ERR_NULL;
  }
  
  for(i=0;i<len;i++)
  {
     *(pdat+i) = ftcomm_data_list[num].rw_buff[ftcomm_data_list[num].r_pointer];//���ݶ���
    
    if(++ftcomm_data_list[num].r_pointer>ftcomm_data_list[num].rw_size)//������������С
    {
      ftcomm_data_list[num].r_pointer = 0;//ָ����0
    }
  }

  return FTCOMM_ERR_NONE;
}

/*******************************************************************************
* FunctionName   : U16 Link_Get_len(U8 num)
* Description    : ��ȡ���ݳ���
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

U16 Link_Get_len(U8 num)
{
  U16 temp_len = 0;
  
  if(num>FTCMM_NUM)//֡���ж�
  {
    return FTCOMM_ERR_INVA;
  }
  
  temp_len = ((ftcomm_data_list[num].w_pointer > ftcomm_data_list[num].r_pointer) ? 
          ((ftcomm_data_list[num].w_pointer - ftcomm_data_list[num].r_pointer)) :
          ((ftcomm_data_list[num].w_pointer + ftcomm_data_list[num].rw_size) - ftcomm_data_list[num].r_pointer));
  
  return temp_len;
}

/*######################################�������ʵ��#############################*/

/*���ڴ����������ݽṹ�洢ʹ��*/

void Link_Alter_Write_Dat(U8 a_ch,U8 num,U8 dat)
{
  switch(a_ch)
  {
    case FTCOMM_ALTER_0:Link_Wirte_Dat(num,dat);break;
    case FTCOMM_ALTER_1:Link_WirteLQueue_Dat(num,dat);break;
    case FTCOMM_ALTER_2:break;
    case FTCOMM_ALTER_3:break;
    default:break;
  }
}

U8 Link_Alter_Read_Dat(U8 a_ch,U8 num,U8 dat)
{
  U8 temp_value = 0;
    
  switch(a_ch)
  {
    case FTCOMM_ALTER_0:temp_value = Link_Read_Dat(num,&dat);break;
    case FTCOMM_ALTER_1:temp_value = Link_ReadLQueue_Dat(num,dat);break;
    case FTCOMM_ALTER_2:break;
    case FTCOMM_ALTER_3:break;
    default:break;
  }
  return temp_value;
}

U16 Link_Alter_Get_Len(U8 a_ch,U8 num)
{
  U16 temp_len = 0;
  
  switch(a_ch)
  {
    case FTCOMM_ALTER_0:temp_len = Link_Get_len(num);break;
    case FTCOMM_ALTER_1:temp_len = Link_GetLQueue_len(num);break;
    case FTCOMM_ALTER_2:break;
    case FTCOMM_ALTER_3:break;
    default:temp_len = 0;break;
  }
  return temp_len;
}

/*******************************************************************************
* FunctionName   : void Link_Clear_Frame(FTCOMM_FRAME_LIST *p_frame)
* Description    : �������֡
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

void Link_Clear_Frame(FTCOMM_FRAME_LIST *p_frame)
{
  p_frame->frame_header_flag = 0;
  p_frame->frame_len = 0;
  memset(p_frame->frame_rbuff,0,p_frame->frame_size);
}

/*******************************************************************************
* FunctionName   : void Link_Get_FrameHead(FTCOMM_FRAME_LIST *p_frame,U8 dat)
* Description    : ��ȡһ֡����֡ͷ
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

void Link_Get_FrameHead(FTCOMM_FRAME_LIST *p_frame,U8 dat)
{
  if(p_frame->head[0]<=2)//�����ֽڵ�֡ͷ
  {
    if(dat == p_frame->head[p_frame->frame_header_flag+1])//head[1]
    {
      p_frame->frame_rbuff[p_frame->frame_len++] = dat;//��������
      p_frame->frame_header_flag++;//ָ��֡ͷ
      return;
    }
  }
  else //֡ͷ��Ŀ����
  {
  }
  Link_Clear_Frame(p_frame);
}

/*******************************************************************************
* FunctionName   : U8 Link_Get_FrameTail(FTCOMM_FRAME_LIST *p_frame)
* Description    : ��ȡһ֡����֡β
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

U8 Link_Get_FrameTail(FTCOMM_FRAME_LIST *p_frame)
{
  if(p_frame->tail[0]==1)//һ��֡β
  {
    if(p_frame->frame_rbuff[p_frame->frame_len-1] == p_frame->tail[1])
    {
      return FTCOMM_ERR_NONE;
    }
   
  }
  else if(p_frame->tail[0]==2)
  {
    if((p_frame->frame_rbuff[p_frame->frame_len-2] == p_frame->tail[1])&&
      (p_frame->frame_rbuff[p_frame->frame_len-1] == p_frame->tail[2]))
    {
      return FTCOMM_ERR_NONE;
    }

  }
  else//�������
  {
    return FTCOMM_ERR_DATA;
  }
  
  return FTCOMM_ERR_DATA;
}

/*******************************************************************************
* FunctionName   : U8 Link_Get_Frame(U8 num,FTCOMM_FRAME_LIST *p_frame)
* Description    : ��ȡһ֡����
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

U8 Link_Get_Frame(U8 num,FTCOMM_FRAME_LIST *p_frame)
{
  U16 i = 0;
  U16 temp_len = 0;
  U8 temp_dat = 0;
  
  if(num>FTCMM_NUM)//֡���ж�
  {
    return FTCOMM_ERR_INVA;
  }
  
  temp_len = Link_Alter_Get_Len(0,num);//��ȡ֡����
  
  for(i=0;i<temp_len;i++)//����
  {
    if(Link_Read_Dat(num,&temp_dat) == FTCOMM_ERR_NONE)
    //if(Link_Alter_Read_Dat(0,num,temp_dat) == FTCOMM_ERR_NONE)//��ȡ���ݳɹ�
    {
      if(p_frame->frame_header_flag<p_frame->head[0])//û�ж���֡ͷ
      { 
        
        Link_Get_FrameHead(p_frame,temp_dat);
        
      }
      else//֡ͷ��ȡ�ɹ�  
      {
        p_frame->frame_rbuff[p_frame->frame_len++] = temp_dat;//ת������
        
        if(Link_Get_FrameTail(p_frame) == FTCOMM_ERR_NONE)//֡β����ɹ�
        {
          if((p_frame->min_len == 0)||((p_frame->min_len>0)&&(p_frame->frame_len>p_frame->min_len)))//��С֡����
          {
            //��С֡����>7
            return FTCOMM_ERR_NONE;
            
          }
          else
          {
            Link_Clear_Frame(p_frame);
          }
        }
        if(p_frame->frame_len>p_frame->frame_size)//Խ��
        {
          Link_Clear_Frame(p_frame);
        }
      }
    }
  }
  
 return FTCOMM_ERR_DATA;
}

/*******************************************************************************
* FunctionName   : U8 Link_Frame_Link(U8 num,FTCOMM_FRAME_LIST *p_frame)
* Description    : ��ȡһ֡����Link
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

U8 Link_Frame_Link(U8 num,FTCOMM_FRAME_LIST *p_frame)
{
  while(ftcomm_data_list[num].w_pointer!=ftcomm_data_list[num].r_pointer)//���ݴ���
  {
    if(Link_Get_Frame(num,p_frame) == FTCOMM_ERR_NONE)//һ֡���ݴ������
    {
      return FTCOMM_ERR_NONE;
    }
  }
  return FTCOMM_ERR_DATA;
}

/*******************************************************************************
* FunctionName   : void Link_FrameData_Init(void)
* Description    : ��ʼ��
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

void Link_FrameData_Init(void)
{
  U8 i = 0;
  
  for(i=0;i<FTCMM_NUM;i++)
  {
    ftcomm_data_list[i].w_pointer = 0X0000;
    ftcomm_data_list[i].r_pointer = 0X0000;
    ftcomm_data_list[i].rw_size = 0X0000;
    ftcomm_data_list[i].rw_buff = NULL;
  }
}

/*******************************************************************************
* FunctionName   : U8 Mid_Comm_FrameData_Create(U8 num,U8 *pdat,U16 size)
* Description    : ��ȡһ֡����Link
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

U8 Link_FrameData_Create(U8 num,U8 *pdat,U16 size)
{
  if(num>FTCMM_NUM)//֡���ж�
  {
    return FTCOMM_ERR_INVA;
  }
  
  ftcomm_data_list[num].w_pointer = 0X0000;
  ftcomm_data_list[num].r_pointer = 0X0000;
  ftcomm_data_list[num].rw_size = size;
  ftcomm_data_list[num].rw_buff = pdat;
  
  memset(ftcomm_data_list[num].rw_buff,0,ftcomm_data_list[num].rw_size);
  
  return FTCOMM_ERR_NULL;
}

/*******************************************************************************
* FunctionName   : void Link_FrameFormat_Create(U8 *head,U8 *tail,U8 min_len,U8 *pdat,U16 buffsize,FTCOMM_FRAME_LIST *p_frame)
* Description    : ����֡��ʽ
* EntryParameter : ��
* ReturnValue    : ����
********************************************************************************/

void Link_FrameFormat_Create(U8 *head,U8 *tail,U8 min_len,U8 *pdat,U16 buffsize,FTCOMM_FRAME_LIST *p_frame)
{
  if((p_frame->head[0]<=2)&&(p_frame->tail[0]<=2))
  {
    p_frame->frame_len = 0X0000;
    p_frame->frame_size = buffsize;
    p_frame->frame_rbuff = pdat;
    p_frame->min_len = min_len;
    
    memcpy(p_frame->head,head,3);
    memcpy(p_frame->tail,tail,3);
    memset(p_frame->frame_rbuff,0,p_frame->frame_size);
  }
  else
  {

  }
}





































