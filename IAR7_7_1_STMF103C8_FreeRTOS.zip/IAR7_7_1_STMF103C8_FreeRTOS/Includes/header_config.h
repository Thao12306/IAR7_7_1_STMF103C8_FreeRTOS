/*  
*header_config.h V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : 
*DebugTools     : 
*Description    : ϵͳ���õ�ͷ�ļ� 
*
*
*/

#ifndef __HEADER_CONFIG_H__
#define __HEADER_CONFIG_H__

/*######################################��׼��ͷ�ļ�############################*/

#include "stdio.h"      /*printf scanf*/
#include "string.h"     /**/
#include <stdlib.h>     /*malloc */

/*######################################ϵͳͷ�ļ�##############################*/

#include "stm32f10x.h"

/*##################################����ϵͳ FreeRTOSͷ�ļ�#####################*/

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/*#####################################Driverͷ�ļ�#############################*/

#include "../Driver_Layer/USART&UART/usart.h"
#include "../Driver_Layer/SPI/spi.h"
#include "../Driver_Layer/FLASH_W25QXX/w25qxx.h"
#include "../Driver_Layer/DMA_FLASH/dma_flash.h"
#include "../Driver_Layer/DMA_USART/dma_usart.h"
#include "../Driver_Layer/KEY/key.h"

/*#####################################Linkͷ�ļ�#############################*/

#include "../Link_Layer/FT_COMM/ft_comm.h"

/*#####################################Middleͷ�ļ�#############################*/

#include "../Middle_Layer/COMM_PORT/comm_port.h"


/*#####################################Applicationͷ�ļ�########################*/



/*#####################################Clientͷ�ļ�#############################*/



/*#####################################Otherͷ�ļ�#############################*/

#include "../Other/DATA_STRUCT/data_struct.h"
#include "../Other/CRC/crc.h"
#include "../Other/MATH_CAL/math_cal.h"

/*#####################################ϵͳͷ�ļ�###############################*/

#include "../Includes/type.h"
#include "../Includes/set_parameters.h"


#endif

/*######################################## END OF FILE #########################*/

