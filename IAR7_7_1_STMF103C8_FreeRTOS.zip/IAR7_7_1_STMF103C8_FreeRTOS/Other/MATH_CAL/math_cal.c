/*  
*math_cal.c V1.0                                                                     
*Copyright (C) 2018 Company Name, Inc. or its affiliates.  All Rights Reserved. 
*
*Programmer(s)  : LiaoYingYing
*Parameters     : ARM STM32F103X 8Mhz
*DebugTools     : ST-Link & IAR 7.70.1
*Description    : ��ѧ����
*
*
*/

/*######################################ͷ�ļ�##################################*/

#include "../Includes/header_config.h"

/*######################################ȫ�ֱ���################################*/


/*######################################����ʵ��################################*/

/*******************************************************************************
* FunctionName   : U16 Data_Escape(U8 *pout,U8 *pin,U16 len)
* Description    : ����ת��
* EntryParameter : 
* ReturnValue    : ����
********************************************************************************/

U16 Data_Escape(U8 *pout,U8 *pin,U16 len)
{
  U16 i = 0;
  U16 temp_len = 0;
  
  for(i=0;i<len;i++)
  {
    if((i == 0)||(i == (len-1)))//����֡ͷ֡β
    {
      pout[temp_len++] = pin[i];
    }
    else//��������������Ҫת��
    {
      if((pin[i] == COMM_HEAD_CODE)||(pin[i] == COMM_TAIL_CODE))//������֡ͷ֡β������ͬ
      {
        pout[temp_len++] = 0X33;
        pout[temp_len++] = pin[i]-0X11;
      }
      else
      {
        pout[temp_len++] = pin[i];
      }
    }
  }
  return temp_len;
}

/*******************************************************************************
* FunctionName   : U16 Mid_Send_Data_Escape(U8 *pout,U8 *pin,U16 len)
* Description    : ���ݷ�ת��
* EntryParameter : 
* ReturnValue    : ����
********************************************************************************/

U16 Data_UnEscape(U8 *pout,U8 *pin,U16 len)
{
  U16 i = 0;
  U16 temp_len = 0;
  
  for(i=0;i<len;i++)
  {
    pout[temp_len++] = (pin[i]==0X33)? (pin[++i]+0X11):(pin[i]);
  }
  
  return temp_len;
}













